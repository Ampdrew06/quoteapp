import React, { useMemo } from "react";
import NavTabs from "../../components/NavTabs";
import TemplateGeometryVisualizer from "../../components/TemplateGeometryVisualizer";
import WallplateGeometryVisualizer from "../../components/WallplateGeometryVisualizer";
import HippedWallplateFrontVisualizer from "../../components/HippedWallplateFrontVisualizer";
import { getMaterials } from "../../lib/materials";
import { buildAutomaticRoofTiling } from "../../lib/Calculations/automaticRoofTiling";
import { buildAutomaticRoofEdgeBOM } from "../../lib/Calculations/automaticRoofEdgeBOM";
import { buildHipManufactureAudit } from "../../lib/Calculations/hipManufactureAudit";
import { buildJackRafterManufactureAudit } from "../../lib/Calculations/jackRafterManufactureAudit";
import { buildHippedLeanToRingBeamSchedule } from "../../lib/Manufacturing/ringBeamManufactureSchedule";
import {
  buildRingBeamIntegrationAudit,
  buildRingBeamPlyBaseIntegrationAudit,
  buildRingBeamPlyUpstandIntegrationAudit,
  buildRingBeamOuterLathIntegrationAudit,
  buildRingBeamFinishingLathIntegrationAudit,
  buildRingBeamPirIntegrationAudit,
  buildRingBeamSummaryConsolidation,
} from "../../lib/Calculations/ringBeamIntegrationAudit";
import {
  buildHippedWallplateIntegrationAudit,
  buildWallplateSummaryProposal,
} from "../../lib/Calculations/wallplateIntegrationAudit";
import { buildProvisionalHippedLeanToTimber } from "../../lib/Calculations/provisionalHippedLeanToTimber";
import { buildHippedLeanToInsulationAudit } from "../../lib/Calculations/insulationIntegrationAudit";
import { buildLeanToTotals } from "../../lib/leanToTotals";
import { calculateLeanToGeometry } from "../../lib/geometry/leanToGeometry";

const loadInputs = () => {
  try {
    return JSON.parse(localStorage.getItem("leanToInputs") || "{}");
  } catch {
    return {};
  }
};

const round = (value, dp = 0) => {
  const power = 10 ** dp;
  return Math.round((Number(value) || 0) * power) / power;
};

const loadObject = (key) => {
  try {
    return JSON.parse(localStorage.getItem(key) || "{}");
  } catch {
    return {};
  }
};

const panel = {
  marginBottom: 16,
  padding: 16,
  border: "1px solid #cbd5e1",
  borderRadius: 10,
  background: "#fff",
};

const th = {
  padding: "7px 9px",
  border: "1px solid #d1d5db",
  background: "#f1f5f9",
  textAlign: "left",
  fontSize: 13,
};

const td = {
  padding: "7px 9px",
  border: "1px solid #d1d5db",
  fontSize: 13,
  verticalAlign: "top",
};

export default function LeanToTechnical() {
  const roofInputs = useMemo(loadInputs, []);
  const materials = useMemo(() => getMaterials(), []);
  const summaryExclusions = useMemo(
    () => loadObject("summary_exclusions"),
    []
  );
  const summaryAdjustments = useMemo(
    () => loadObject("summary_adjustments"),
    []
  );
  const summaryAdjustmentValues = useMemo(
    () => loadObject("summary_adjustment_values"),
    []
  );
  const summaryExclusionValues = useMemo(
    () => loadObject("summary_exclusion_values"),
    []
  );

  const quoteTotals = useMemo(
    () => buildLeanToTotals(roofInputs, summaryExclusions),
    [roofInputs, summaryExclusions]
  );

  const adjustmentDelta = useMemo(
    () =>
      [
        ...Object.values(summaryAdjustmentValues),
        ...Object.values(summaryExclusionValues),
      ].reduce((sum, value) => {
        const number = Number(value);
        return Number.isFinite(number) ? sum + number : sum;
      }, 0),
    [summaryAdjustmentValues, summaryExclusionValues]
  );

  const automatic = useMemo(
    () => buildAutomaticRoofTiling({ roofInputs, materials }),
    [roofInputs, materials]
  );

  const geometry = automatic?.geometry || null;
  const isHipped = automatic?.roofStyle === "hippedLeanTo" && geometry;

  const edgeResult = useMemo(
    () =>
      buildAutomaticRoofEdgeBOM({
        roofInputs,
        materials,
        automaticRoofTiling: automatic,
      }),
    [roofInputs, materials, automatic]
  );

  const hipAudit = useMemo(
    () =>
      buildHipManufactureAudit({
        roofInputs,
        geometry,
        edgeModel: edgeResult?.edgeModel,
      }),
    [roofInputs, geometry, edgeResult]
  );

  const jackAudit = useMemo(
    () => buildJackRafterManufactureAudit({ roofInputs, geometry }),
    [roofInputs, geometry]
  );

  const ringSchedule = useMemo(
    () =>
      isHipped
        ? buildHippedLeanToRingBeamSchedule({ geometry })
        : null,
    [isHipped, geometry]
  );

  const wallplateIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildHippedWallplateIntegrationAudit({
            geometry,
            currentSummaryExternalWidthMM:
              quoteTotals?.derived?.extWidthMM,
          })
        : null,
    [isHipped, geometry, quoteTotals]
  );

  const provisionalHippedTimber = useMemo(
    () =>
      isHipped
        ? buildProvisionalHippedLeanToTimber({
            roofInputs,
            geometry,
          })
        : null,
    [isHipped, roofInputs, geometry]
  );

  const ringBeamIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamIntegrationAudit({
            currentSummaryQuantityM:
              Number(quoteTotals?.derived?.extWidthMM || 0) / 1000,
            ringSchedule,
            stockLengthM: materials?.pse30x90?.stock_len_m ?? 4.8,
          })
        : null,
    [isHipped, quoteTotals, ringSchedule, materials]
  );

  const ringBeamPlyBaseIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamPlyBaseIntegrationAudit({
            currentSummaryExternalWidthMM:
              quoteTotals?.derived?.extWidthMM,
            currentSummaryBaseWidthMM:
              Number(
                roofInputs?.soffit_mm ??
                  roofInputs?.eaves_overhang_mm ??
                  150
              ) + 70,
            ringSchedule,
          })
        : null,
    [isHipped, quoteTotals, roofInputs, ringSchedule]
  );

  const ringBeamPlyUpstandIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamPlyUpstandIntegrationAudit({
            currentSummaryExternalWidthMM:
              quoteTotals?.derived?.extWidthMM,
            currentSummaryUpstandHeightMM: 195,
            ringSchedule,
          })
        : null,
    [isHipped, quoteTotals, ringSchedule]
  );

  const ringBeamOuterLathIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamOuterLathIntegrationAudit({
            currentSummaryQuantityM: 0,
            ringSchedule,
          })
        : null,
    [isHipped, ringSchedule]
  );

  const ringBeamFinishingLathIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamFinishingLathIntegrationAudit({
            currentSummaryInternalWidthMM: geometry?.widthMM,
            rafterSpacingMM: materials?.rafter_spacing_mm ?? 665,
            firstRafterCentreMM:
              materials?.rafter_first_center_mm ?? 690,
            assumedBayWidthMM: 617,
            ringSchedule,
          })
        : null,
    [isHipped, geometry, materials, ringSchedule]
  );

  const ringBeamPirIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildRingBeamPirIntegrationAudit({
            currentSummaryExternalWidthMM:
              quoteTotals?.derived?.extWidthMM,
            currentSummaryPirHeightMM: 185,
            ringSchedule,
          })
        : null,
    [isHipped, quoteTotals, ringSchedule]
  );

  const currentSummarySupportingQuantities = useMemo(() => {
    if (!isHipped) return null;

    const widthMM = Number(geometry?.widthMM ?? 0);
    const projectionMM = Number(geometry?.projectionMM ?? 0);
    const pitchDeg = Number(geometry?.frontPitchDeg ?? 0);
    const soffitDepthMM = Number(
      roofInputs?.soffit_mm ?? roofInputs?.eaves_overhang_mm ?? 150
    );
    const frameOnMM = Number(
      roofInputs?.frame_on_mm ?? materials?.frame_on_mm ?? 70
    );
    const spacingMM = Number(materials?.rafter_spacing_mm ?? 665);
    const firstCentreMM = Number(materials?.rafter_first_center_mm ?? 690);

    const sharedLeanToGeometry = calculateLeanToGeometry({
      widthMM,
      projectionMM,
      pitchDeg,
      soffitDepthMM,
      materials,
    });
    const frontRafterLengthMM = Number(
      sharedLeanToGeometry?.rafterExternalLength ?? 0
    );
    const internalRows =
      pitchDeg > 0 ? Math.ceil(frontRafterLengthMM / 400) : 0;

    let centreCount = 0;
    if (widthMM > 0 && spacingMM > 0 && firstCentreMM > 0) {
      for (
        let centreMM = firstCentreMM;
        centreMM <= widthMM;
        centreMM += spacingMM
      ) {
        centreCount += 1;
      }
    }
    const rafterCount = Math.max(2, centreCount + 2);
    const cradleFaces = Math.max(0, 2 * rafterCount - 2);
    const pitchRadians = (pitchDeg * Math.PI) / 180;
    const cradleFaceLengthMM =
      (projectionMM + frameOnMM) / (Math.cos(pitchRadians) || 1);
    const cradleRawM2 =
      (cradleFaces * cradleFaceLengthMM * 140) / 1_000_000;
    const cradleWastePercent = Number(materials?.pir50?.waste_pct ?? 0);

    return {
      externalTilingLathM:
        Number(automatic?.result?.lathLengthMM ?? 0) / 1000,
      internalFixingLathM: internalRows * (widthMM / 1000),
      ringBeamFinishingLathM: Number(
        ringBeamFinishingLathIntegrationAudit?.currentSummaryQuantityM ?? 0
      ),
      pirCradleAreaM2:
        cradleRawM2 * (1 + cradleWastePercent / 100),
    };
  }, [
    isHipped,
    geometry,
    roofInputs,
    materials,
    automatic,
    ringBeamFinishingLathIntegrationAudit,
  ]);

  const ringBeamSummaryConsolidation = useMemo(
    () =>
      isHipped
        ? buildRingBeamSummaryConsolidation({
            currentSummaryExternalWidthMM:
              quoteTotals?.derived?.extWidthMM,
            currentSummaryBaseWidthMM:
              Number(
                roofInputs?.soffit_mm ??
                  roofInputs?.eaves_overhang_mm ??
                  150
              ) + 70,
            currentSummaryUpstandHeightMM: 195,
            currentSummaryWallplateFaceHeightMM: 220,
            currentExternalTilingLathM:
              currentSummarySupportingQuantities?.externalTilingLathM,
            currentInternalFixingLathM:
              currentSummarySupportingQuantities?.internalFixingLathM,
            currentRingBeamFinishingLathM:
              currentSummarySupportingQuantities?.ringBeamFinishingLathM,
            currentPirCradleAreaM2:
              currentSummarySupportingQuantities?.pirCradleAreaM2,
            currentPirCradleWeightMultiplier:
              materials?.pir50_cradle_weight_multiplier ?? 1,
            currentSummaryPirHeightMM: 185,
            ringSchedule,
            materials,
          })
        : null,
    [
      isHipped,
      quoteTotals,
      roofInputs,
      ringSchedule,
      materials,
      currentSummarySupportingQuantities,
    ]
  );

  const wallplateSummaryProposal = useMemo(
    () =>
      isHipped
        ? buildWallplateSummaryProposal({
            wallplateAudit: wallplateIntegrationAudit,
            steicoRoofMembersM:
              Number(
                provisionalHippedTimber?.totals
                  ?.steicoRoofMemberLengthMM ?? 0
              ) / 1000,
            integratedPly9M2:
              ringBeamSummaryConsolidation?.lines?.ply9mm
                ?.proposedQuantity,
            materials,
          })
        : null,
    [
      isHipped,
      wallplateIntegrationAudit,
      provisionalHippedTimber,
      ringBeamSummaryConsolidation,
      materials,
    ]
  );

  const insulationIntegrationAudit = useMemo(
    () =>
      isHipped
        ? buildHippedLeanToInsulationAudit({
            roofInputs,
            geometry,
            ringSchedule,
            currentSummaryPir50AreaM2:
              ringBeamSummaryConsolidation?.lines?.pir50
                ?.proposedQuantity,
            memberWidthMM: 48,
            cradleStripWidthMM: 140,
            wastePercent: Number(
              materials?.slab100_wastage_pct ??
                materials?.pir50?.waste_pct ??
                5
            ),
            sheetWidthMM:
              Number(materials?.pir100?.sheet_w_m ?? 1.2) * 1000,
            sheetLengthMM:
              Number(materials?.pir100?.sheet_h_m ?? 2.4) * 1000,
            internalLathCentresMM: Number(
              roofInputs?.int_lath_centres_mm ?? 400
            ),
            superQuiltOverlapMM: Number(
              materials?.superquilt_overlap_mm ?? 50
            ),
            superQuiltWastePercent: Number(
              materials?.superquilt_wastage_pct ?? 6
            ),
            superQuiltRollWidthMM: Number(
              materials?.superquilt_roll_width_mm ?? 1200
            ),
            superQuilt12Price: Number(
              materials?.superquilt_12m_price_each ??
                materials?.superquilt_12m2_price_ex_vat ??
                0
            ),
            superQuilt15Price: Number(
              materials?.superquilt_15m_price_each ??
                materials?.superquilt_15m2_price_ex_vat ??
                0
            ),
            currentSummaryInternalLathM:
              currentSummarySupportingQuantities?.internalFixingLathM,
          })
        : null,
    [
      isHipped,
      roofInputs,
      geometry,
      ringSchedule,
      ringBeamSummaryConsolidation,
      currentSummarySupportingQuantities,
      materials,
    ]
  );

  return (
    <div style={{ fontFamily: "Inter, system-ui, Arial", background: "#f8fafc", minHeight: "100vh" }}>
      <NavTabs />
      <main style={{ maxWidth: 1180, margin: "0 auto", padding: 16 }}>
        <h1 style={{ marginBottom: 4 }}>Technical</h1>
        <p style={{ marginTop: 0, color: "#475569" }}>
          Visualisers, geometry diagnostics and read-only integration evidence for the current Design/Options roof.
        </p>

        <section style={panel}>
          <h2 style={{ marginTop: 0 }}>Quotation adjustment diagnostics</h2>
          <p style={{ marginTop: 0, color: "#64748b" }}>
            Technical audit only. The adjustment delta remains included in the quotation price.
          </p>
          <div style={{ display: "grid", gap: 8 }}>
            <div><b>Adjustment delta:</b> £{adjustmentDelta.toFixed(2)}</div>
            <div>
              <b>Adjusted quantity keys:</b>{" "}
              {Object.keys(summaryAdjustments).join(", ") || "None"}
            </div>
            <div style={{ color: "#64748b", fontSize: 12 }}>
              <b>Available material keys:</b>{" "}
              {(quoteTotals?.allLines || []).map((line) => line.key).join(", ") || "None"}
            </div>
          </div>
        </section>

        {!isHipped ? (
          <section style={panel}>
            <b>No Hipped Lean-To technical geometry is available.</b>
            <div style={{ marginTop: 6, color: "#64748b" }}>
              Create or load a Hipped Lean-To on Design/Options first.
            </div>
          </section>
        ) : (
          <>
            <section style={panel}>
              <h2 style={{ marginTop: 0 }}>Geometry summary</h2>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 8 }}>
                <div><b>Internal size:</b> {round(geometry.widthMM)} × {round(geometry.projectionMM)} mm</div>
                <div><b>External size:</b> {round(geometry.externalWidthMM)} × {round(geometry.externalProjectionMM)} mm</div>
                <div><b>Front pitch:</b> {round(geometry.frontPitchDeg, 1)}°</div>
                <div><b>Side pitches:</b> {round(geometry.leftSidePitchDeg, 1)}° / {round(geometry.rightSidePitchDeg, 1)}°</div>
                <div><b>Left boss:</b> {round(geometry.resolvedLeftHipWidthMM)} mm</div>
                <div><b>Right boss:</b> {round(geometry.widthMM - geometry.resolvedRightHipWidthMM)} mm</div>
                <div><b>Front timber HFC:</b> {round(geometry.frontTemplateDebug?.horizontalFootRunMM, 1)} mm</div>
                <div><b>Side timber HFC:</b> {round(geometry.leftTemplateDebug?.horizontalFootRunMM, 1)} mm</div>
                <div><b>Side ply base:</b> {round(geometry.leftTemplateDebug?.plyBaseWidthMM, 1)} mm</div>
              </div>
            </section>

            {geometry.frontTemplateDebug && geometry.leftTemplateDebug && (
              <TemplateGeometryVisualizer
                frontTemplate={geometry.frontTemplateDebug}
                sideTemplate={geometry.leftTemplateDebug}
                matchedSideSoffitMM={geometry.leftPlumbCutMatchedSoffitMM}
                mitreTrimAllowanceMM={geometry.leftMitreTrimAllowanceMM}
                manufacturedSideSoffitMM={geometry.leftRoundedManufacturedSoffitMM}
              />
            )}

            <WallplateGeometryVisualizer
              projectionMM={geometry.projectionMM}
              frontPitchDeg={geometry.frontPitchDeg}
              designRiseMM={geometry.designRiseMM}
              frontRafterFaceRiseMM={geometry.frontRafterFaceRiseMM}
              effectivePitchRunMM={geometry.effectivePitchRunMM}
              internalWallplateHeightMM={geometry.designInternalWallplateHeightMM}
              externalWallplateHeightMM={geometry.designExternalWallplateHeightMM}
              wallplateThicknessMM={geometry.raw?.wallplateThicknessMM ?? 63}
              wallplateHeightMM={geometry.wallplateHeightMM ?? 220}
              ringBeamHeightMM={geometry.ringBeamHeightMM ?? 40}
            />

            <HippedWallplateFrontVisualizer
              internalWidthMM={geometry.widthMM}
              leftHipPositionMM={geometry.resolvedLeftHipWidthMM}
              rightHipPositionMM={geometry.resolvedRightHipWidthMM}
              leftSidePitchDeg={geometry.leftSidePitchDeg}
              rightSidePitchDeg={geometry.rightSidePitchDeg}
              internalWallplateHeightMM={geometry.designInternalWallplateHeightMM}
              externalWallplateHeightMM={geometry.designExternalWallplateHeightMM}
              wallplateSectionHeightMM={geometry.wallplateHeightMM ?? 220}
              leftWallBarFootRunMM={geometry.leftTemplateDebug?.horizontalFootRunMM ?? 0}
              rightWallBarFootRunMM={geometry.rightTemplateDebug?.horizontalFootRunMM ?? geometry.leftTemplateDebug?.horizontalFootRunMM ?? 0}
              leftWallBarVerticalFootCutMM={geometry.leftPlumbCutHeightMM}
              rightWallBarVerticalFootCutMM={geometry.rightPlumbCutHeightMM}
              externalWidthMM={geometry.externalWidthMM}
              leftExternalAllowanceMM={geometry.leftExternalAllowanceMM}
              rightExternalAllowanceMM={geometry.rightExternalAllowanceMM}
            />

            {hipAudit?.valid && (
              <section style={panel}>
                <h2 style={{ marginTop: 0 }}>Hip manufacturing audit — read only</h2>
                {hipAudit.hips.map((hip) => (
                  <div key={hip.side} style={{ marginTop: 12 }}>
                    <b>{hip.manufactureRef ? `${hip.manufactureRef} · ` : ""}{hip.side} hip</b>
                    <span style={{ color: "#475569" }}> · pitch {round(hip.hipPitchDeg, 2)}° · plan {round(hip.hipPlanLengthMM, 1)} mm</span>
                    <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 6 }}>
                      <tbody>
                        {hip.measurements.map((measurement) => (
                          <tr key={measurement.key}>
                            <td style={td}>{measurement.key}</td>
                            <td style={{ ...td, textAlign: "right" }}>{round(measurement.calculatedMM, 1)} mm</td>
                            {measurement.referenceMM != null && <td style={{ ...td, textAlign: "right" }}>Reference {round(measurement.referenceMM)} mm</td>}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ))}
              </section>
            )}

            {jackAudit?.valid && (
              <section style={panel}>
                <h2 style={{ marginTop: 0 }}>Jack rafter manufacturing audit — read only</h2>
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Facet</th><th style={th}>Ref</th><th style={th}>Position</th><th style={th}>Pitch</th><th style={th}>Internal</th><th style={th}>External</th><th style={th}>HFC</th><th style={th}>VFC</th></tr></thead>
                    <tbody>
                      {jackAudit.jacks.map((jack) => (
                        <tr key={jack.id}>
                          <td style={td}>{jack.facetId}</td><td style={td}>{jack.manufactureRef || "—"}</td>
                          <td style={td}>{round(jack.positionMM)} mm</td><td style={td}>{round(jack.profile.facetPitchDeg, 2)}°</td>
                          <td style={td}>{round(jack.profile.internalSlopeLengthMM, 1)} mm</td><td style={td}>{round(jack.profile.externalSlopeLengthMM, 1)} mm</td>
                          <td style={td}>{round(jack.profile.horizontalFootCutMM, 1)} mm</td><td style={td}>{round(jack.profile.verticalFootCutMM, 1)} mm</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>
            )}

            {insulationIntegrationAudit?.valid && (
              <section style={panel}>
                <h2 style={{ marginTop: 0 }}>Integration Audit — roof insulation</h2>
                <p style={{ color: "#92400e" }}>
                  The audited 50 mm PIR, 100 mm PIR, SuperQuilt and internal fixing-lath quantities now feed the live Summary.
                </p>

                <h3>100 mm PIR — insulation bays</h3>
                <div style={{ overflowX: "auto", marginBottom: 18 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Front facet</th><th style={th}>Left facet</th><th style={th}>Right facet</th><th style={th}>Gross internal surface</th><th style={th}>48 mm timber footprint</th><th style={th}>Net PIR</th><th style={th}>With 5% allowance</th><th style={th}>Boards</th></tr></thead>
                    <tbody><tr>
                      <td style={td}>{round(insulationIntegrationAudit.facets.frontM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.facets.leftM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.facets.rightM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir100.grossInternalRoofAreaM2, 3)} m²</td>
                      <td style={td}>−{round(insulationIntegrationAudit.pir100.timberFootprintAreaM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir100.netAreaM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir100.orderAreaM2, 3)} m²</td>
                      <td style={td}><b>{insulationIntegrationAudit.pir100.orderQty}</b></td>
                    </tr></tbody>
                  </table>
                </div>

                <h3>Summary comparison</h3>
                <div style={{ overflowX: "auto", marginBottom: 18 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Material</th><th style={th}>Previous Summary area</th><th style={th}>Integrated area</th><th style={th}>Previous order</th><th style={th}>Integrated order</th><th style={th}>Basis</th></tr></thead>
                    <tbody>
                      <tr>
                        <td style={td}><b>100 mm PIR</b></td>
                        <td style={td}>{round(insulationIntegrationAudit.pir100.currentSummaryAreaM2, 3)} m²</td>
                        <td style={td}>{round(insulationIntegrationAudit.pir100.orderAreaM2, 3)} m²</td>
                        <td style={td}>{insulationIntegrationAudit.pir100.currentSummaryOrderQty}</td>
                        <td style={td}>{insulationIntegrationAudit.pir100.orderQty}</td>
                        <td style={td}>All internal facet surfaces less the 48 mm Steico footprints, then 5% allowance</td>
                      </tr>
                      <tr>
                        <td style={td}><b>50 mm PIR</b></td>
                        <td style={td}>{insulationIntegrationAudit.pir50.currentSummaryAreaM2 == null ? "—" : `${round(insulationIntegrationAudit.pir50.currentSummaryAreaM2, 3)} m²`}</td>
                        <td style={td}>{round(insulationIntegrationAudit.pir50.combinedAreaM2, 3)} m²</td>
                        <td style={td}>{insulationIntegrationAudit.pir50.currentSummaryOrderQty ?? "—"}</td>
                        <td style={td}>{insulationIntegrationAudit.pir50.orderQty}</td>
                        <td style={td}>140 mm rebated cradle strips plus the integrated ring-beam upstand PIR</td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                <h3>50 mm PIR — rebated cradle and ring-beam</h3>
                <div style={{ overflowX: "auto", marginBottom: 12 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Roof-member faces</th><th style={th}>Sloping wallbars</th><th style={th}>Total cradle length</th><th style={th}>140 mm blank area</th><th style={th}>Cradle with 5%</th><th style={th}>Ring-beam upstands</th><th style={th}>Combined 50 mm PIR</th><th style={th}>Boards</th></tr></thead>
                    <tbody><tr>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.roofMemberCradleLengthM, 3)} m</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.wallbarCradleLengthM, 3)} m</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.cradleTotalLengthM, 3)} m</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.cradleNetAreaM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.cradleOrderAreaM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.ringBeamAreaM2, 3)} m²</td>
                      <td style={td}>{round(insulationIntegrationAudit.pir50.combinedAreaM2, 3)} m²</td>
                      <td style={td}><b>{insulationIntegrationAudit.pir50.orderQty}</b></td>
                    </tr></tbody>
                  </table>
                </div>
                <p style={{ marginBottom: 0, color: "#64748b", fontSize: 13 }}>
                  The horizontal wallplate is excluded. Each sloping wallbar contributes one inward-facing cradle strip; every full rafter, jack and hip contributes both insulation-facing sides. Stock boards are {insulationIntegrationAudit.assumptions.sheetWidthMM} × {insulationIntegrationAudit.assumptions.sheetLengthMM} mm.
                </p>

                <h3>SuperQuilt — complete internal surface</h3>
                <div style={{ overflowX: "auto", marginBottom: 18 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Internal surface</th><th style={th}>Overlap</th><th style={th}>Waste</th><th style={th}>Nominal roll area required</th><th style={th}>12 m² rolls</th><th style={th}>15 m² rolls</th><th style={th}>Coverage ordered</th></tr></thead>
                    <tbody><tr>
                      <td style={td}>{round(insulationIntegrationAudit.superQuilt.geometricAreaM2, 3)} m²</td>
                      <td style={td}>{insulationIntegrationAudit.assumptions.superQuiltOverlapMM} mm</td>
                      <td style={td}>{insulationIntegrationAudit.assumptions.superQuiltWastePercent}%</td>
                      <td style={td}>{round(insulationIntegrationAudit.superQuilt.nominalAreaM2, 3)} m²</td>
                      <td style={td}>{insulationIntegrationAudit.superQuilt.rolls12}</td>
                      <td style={td}>{insulationIntegrationAudit.superQuilt.rolls15}</td>
                      <td style={td}><b>{round(insulationIntegrationAudit.superQuilt.coverageM2, 3)} m²</b></td>
                    </tr></tbody>
                  </table>
                </div>

                <h3>25×50 internal plasterboard-fixing laths</h3>
                <div style={{ overflowX: "auto", marginBottom: 12 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Facet</th><th style={th}>Rows</th><th style={th}>Calculated length</th><th style={th}>Rule</th></tr></thead>
                    <tbody>
                      <tr><td style={td}>Front</td><td style={td}>{insulationIntegrationAudit.internalLaths.front.rowCount}</td><td style={td}>{round(insulationIntegrationAudit.internalLaths.front.metres, 3)} m</td><td style={td}>Trapezoid: ring-beam row, {insulationIntegrationAudit.assumptions.internalLathCentresMM} mm centres, final wallplate row</td></tr>
                      <tr><td style={td}>Left side</td><td style={td}>{insulationIntegrationAudit.internalLaths.left.rowCount}</td><td style={td}>{round(insulationIntegrationAudit.internalLaths.left.metres, 3)} m</td><td style={td}>Triangle: rows narrow from wallbar to hip</td></tr>
                      <tr><td style={td}>Right side</td><td style={td}>{insulationIntegrationAudit.internalLaths.right.rowCount}</td><td style={td}>{round(insulationIntegrationAudit.internalLaths.right.metres, 3)} m</td><td style={td}>Triangle: rows narrow from wallbar to hip</td></tr>
                      <tr><td style={td}><b>Total</b></td><td style={td}><b>{insulationIntegrationAudit.internalLaths.front.rowCount + insulationIntegrationAudit.internalLaths.left.rowCount + insulationIntegrationAudit.internalLaths.right.rowCount}</b></td><td style={td}><b>{round(insulationIntegrationAudit.internalLaths.totalM, 3)} m</b></td><td style={td}>Previous Summary: {insulationIntegrationAudit.internalLaths.currentSummaryM == null ? "—" : `${round(insulationIntegrationAudit.internalLaths.currentSummaryM, 3)} m`}</td></tr>
                    </tbody>
                  </table>
                </div>
                <p style={{ marginBottom: 0, color: "#64748b", fontSize: 13 }}>
                  Internal laths are measured from the internal facet boundaries; unlike external tiling laths, soffits and external tile overhangs are excluded.
                </p>
              </section>
            )}

            {wallplateIntegrationAudit?.valid && (
              <section style={panel}>
                <h2 style={{ marginTop: 0 }}>Integration Audit — wallplate</h2>
                <p style={{ color: "#92400e" }}>
                  Read only. These quantities do not yet replace Summary pricing or manufacturing output.
                </p>

                <h3>Assembly quantities</h3>
                <div style={{ overflowX: "auto", marginBottom: 18 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={th}>Material</th>
                        <th style={th}>Current Summary</th>
                        <th style={th}>Manufacture-derived</th>
                        <th style={th}>Difference</th>
                        <th style={th}>Status</th>
                        <th style={th}>Basis</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        [
                          "Steico 220 wallplate members",
                          wallplateIntegrationAudit.steico,
                          wallplateIntegrationAudit.steico.formula,
                        ],
                        [
                          "9 mm wallplate faceplates / rear packers",
                          wallplateIntegrationAudit.ply9,
                          `Front faceplate ${round(wallplateIntegrationAudit.ply9.frontFaceplateAreaM2, 3)} m² + rear chevron covers ${round(wallplateIntegrationAudit.ply9.rearChevronCoverAreaM2, 3)} m² + ${wallplateIntegrationAudit.ply9.rearPackerCount} rear packers`,
                        ],
                        [
                          "18 mm wallplate infill / chevrons",
                          wallplateIntegrationAudit.ply18,
                          `143 mm EWPL infill + ${wallplateIntegrationAudit.ply18.chevronCount} × 600 mm chevron blanks`,
                        ],
                      ].map(([label, line, basis]) => (
                        <tr key={label}>
                          <td style={td}><b>{label}</b></td>
                          <td style={td}>{round(line.current, 3)} {line.unit}</td>
                          <td style={td}>{round(line.manufacture, 3)} {line.unit}</td>
                          <td style={td}>
                            {line.difference > 0 ? "+" : ""}
                            {round(line.difference, 3)} {line.unit}
                          </td>
                          <td style={{
                            ...td,
                            color: line.status === "Match" ? "#166534" : "#92400e",
                            fontWeight: 700,
                          }}>
                            {line.status}
                          </td>
                          <td style={td}>{basis}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <h3>Wallplate hardware check</h3>
                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={th}>Component</th>
                        <th style={th}>Current quantity</th>
                        <th style={th}>Required quantity</th>
                        <th style={th}>Status</th>
                        <th style={th}>Rule</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        ["Joist hangers", wallplateIntegrationAudit.hardware.joistHangers],
                        ["Boss / rafter terminals", wallplateIntegrationAudit.hardware.bosses],
                        ["Spar hooks", wallplateIntegrationAudit.hardware.sparHooks],
                      ].map(([label, item]) => (
                        <tr key={label}>
                          <td style={td}><b>{label}</b></td>
                          <td style={td}>{item.current}</td>
                          <td style={td}>{item.manufacture}</td>
                          <td style={{
                            ...td,
                            color: item.status === "Match" ? "#166534" : "#92400e",
                            fontWeight: 700,
                          }}>
                            {item.status}
                          </td>
                          <td style={td}>{item.note || "One per active wallplate joint"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <p style={{ marginBottom: 0, color: "#64748b", fontSize: 13 }}>
                  Rear packers are provisionally 75 × 220 mm and calculated independently on each uncovered run at no more than 800 mm spacing. A boss-position rafter moved away from its boss must later be reclassified as an ordinary rafter: remove its two spar hooks, restore its ordinary length and add one joist hanger.
                </p>

                {wallplateSummaryProposal?.valid && (
                  <>
                    <h3>Proposed consolidated Summary lines — read only</h3>
                    <p style={{ marginTop: -6, color: "#64748b", fontSize: 13 }}>
                      These are complete Summary rows after combining the validated ring-beam quantities with the wallplate audit. Hardware remains unchanged.
                    </p>
                    <div style={{ overflowX: "auto" }}>
                      <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                          <tr>
                            <th style={th}>Summary line</th>
                            <th style={th}>Current qty</th>
                            <th style={th}>Proposed qty</th>
                            <th style={th}>Current order</th>
                            <th style={th}>Proposed order</th>
                            <th style={th}>Current chargeable</th>
                            <th style={th}>Proposed chargeable</th>
                            <th style={th}>Current weight</th>
                            <th style={th}>Proposed weight</th>
                            <th style={th}>Basis</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            ["Steico 220 I-Joists", wallplateSummaryProposal.lines.steico],
                            ["9 mm Structural Ply", wallplateSummaryProposal.lines.ply9mm],
                            ["18 mm Structural Ply", wallplateSummaryProposal.lines.ply18mm],
                          ].map(([label, line]) => (
                            <tr key={label}>
                              <td style={td}><b>{label}</b></td>
                              <td style={td}>{round(line.currentQuantity, 3)} {line.unit}</td>
                              <td style={td}>{round(line.proposedQuantity, 3)} {line.unit}</td>
                              <td style={td}>{line.currentOrderQty ?? "—"}</td>
                              <td style={td}>{line.proposedOrderQty ?? "—"}</td>
                              <td style={td}>£{round(line.currentChargeableCost, 2).toFixed(2)}</td>
                              <td style={td}>£{round(line.proposedChargeableCost, 2).toFixed(2)}</td>
                              <td style={td}>{round(line.currentWeightKg, 2)} kg</td>
                              <td style={td}>{round(line.proposedWeightKg, 2)} kg</td>
                              <td style={td}>{line.note}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}
              </section>
            )}

            {ringSchedule?.valid && (
              <section style={panel}>
                <h2 style={{ marginTop: 0 }}>Integration Audit — ring-beams</h2>
                <p style={{ color: "#92400e" }}>Read only. These quantities do not yet replace Summary pricing.</p>

                <h3>Summary comparison</h3>
                <p style={{ marginTop: -6, color: "#64748b", fontSize: 13 }}>
                  The current Summary quantity is its existing external-width rule. The manufacture quantity includes every active ring-beam.
                </p>
                <div style={{ overflowX: "auto", marginBottom: 18 }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead>
                      <tr>
                        <th style={th}>Material</th>
                        <th style={th}>Current Summary</th>
                        <th style={th}>Manufacture-derived</th>
                        <th style={th}>Difference</th>
                        <th style={th}>Current stock qty</th>
                        <th style={th}>Manufacture stock qty</th>
                        <th style={th}>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td style={td}>30×90 PSE continuous ring-beam timber</td>
                        <td style={td}>{round(ringBeamIntegrationAudit?.currentSummaryQuantityM, 3)} m</td>
                        <td style={td}>{round(ringBeamIntegrationAudit?.manufactureQuantityM, 3)} m</td>
                        <td style={td}>
                          {ringBeamIntegrationAudit?.differenceM > 0 ? "+" : ""}
                          {round(ringBeamIntegrationAudit?.differenceM, 3)} m
                        </td>
                        <td style={td}>{ringBeamIntegrationAudit?.currentSummaryOrderQty ?? "—"}</td>
                        <td style={td}>{ringBeamIntegrationAudit?.manufactureOrderQty ?? "—"}</td>
                        <td style={{
                          ...td,
                          color: ringBeamIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                      <tr>
                        <td style={td}>9 mm ply ring-beam base/soffit</td>
                        <td style={td}>{round(ringBeamPlyBaseIntegrationAudit?.currentSummaryQuantityM2, 3)} m²</td>
                        <td style={td}>{round(ringBeamPlyBaseIntegrationAudit?.manufactureQuantityM2, 3)} m²</td>
                        <td style={td}>
                          {ringBeamPlyBaseIntegrationAudit?.differenceM2 > 0 ? "+" : ""}
                          {round(ringBeamPlyBaseIntegrationAudit?.differenceM2, 3)} m²
                        </td>
                        <td style={td}>Combined 9 mm line</td>
                        <td style={td}>Pending combined audit</td>
                        <td style={{
                          ...td,
                          color: ringBeamPlyBaseIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamPlyBaseIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                      <tr>
                        <td style={td}>9 mm ply ring-beam upstands</td>
                        <td style={td}>{round(ringBeamPlyUpstandIntegrationAudit?.currentSummaryQuantityM2, 3)} m²</td>
                        <td style={td}>{round(ringBeamPlyUpstandIntegrationAudit?.manufactureQuantityM2, 3)} m²</td>
                        <td style={td}>
                          {ringBeamPlyUpstandIntegrationAudit?.differenceM2 > 0 ? "+" : ""}
                          {round(ringBeamPlyUpstandIntegrationAudit?.differenceM2, 3)} m²
                        </td>
                        <td style={td}>Combined 9 mm line</td>
                        <td style={td}>Pending combined audit</td>
                        <td style={{
                          ...td,
                          color: ringBeamPlyUpstandIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamPlyUpstandIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                      <tr>
                        <td style={td}>25×50 outer fixing lath</td>
                        <td style={td}>{round(ringBeamOuterLathIntegrationAudit?.currentSummaryQuantityM, 3)} m</td>
                        <td style={td}>{round(ringBeamOuterLathIntegrationAudit?.manufactureQuantityM, 3)} m</td>
                        <td style={td}>
                          {ringBeamOuterLathIntegrationAudit?.differenceM > 0 ? "+" : ""}
                          {round(ringBeamOuterLathIntegrationAudit?.differenceM, 3)} m
                        </td>
                        <td style={td}>Not currently included</td>
                        <td style={td}>Add manufacture total</td>
                        <td style={{
                          ...td,
                          color: ringBeamOuterLathIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamOuterLathIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                      <tr>
                        <td style={td}>25×50 upstand finishing pieces</td>
                        <td style={td}>{round(ringBeamFinishingLathIntegrationAudit?.currentSummaryQuantityM, 3)} m</td>
                        <td style={td}>{round(ringBeamFinishingLathIntegrationAudit?.manufactureQuantityM, 3)} m</td>
                        <td style={td}>
                          {ringBeamFinishingLathIntegrationAudit?.differenceM > 0 ? "+" : ""}
                          {round(ringBeamFinishingLathIntegrationAudit?.differenceM, 3)} m
                        </td>
                        <td style={td}>Combined 25×50 line</td>
                        <td style={td}>Pending combined audit</td>
                        <td style={{
                          ...td,
                          color: ringBeamFinishingLathIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamFinishingLathIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                      <tr>
                        <td style={td}>50 mm PIR to upstand faces</td>
                        <td style={td}>{round(ringBeamPirIntegrationAudit?.currentSummaryQuantityM2, 3)} m²</td>
                        <td style={td}>{round(ringBeamPirIntegrationAudit?.manufactureQuantityM2, 3)} m²</td>
                        <td style={td}>
                          {ringBeamPirIntegrationAudit?.differenceM2 > 0 ? "+" : ""}
                          {round(ringBeamPirIntegrationAudit?.differenceM2, 3)} m²
                        </td>
                        <td style={td}>Combined 50 mm PIR line</td>
                        <td style={td}>Pending combined audit</td>
                        <td style={{
                          ...td,
                          color: ringBeamPirIntegrationAudit?.status === "Match" ? "#166534" : "#92400e",
                          fontWeight: 700,
                        }}>
                          {ringBeamPirIntegrationAudit?.status || "Unavailable"}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {ringBeamSummaryConsolidation?.valid && (
                  <>
                    <h3>Proposed consolidated Summary lines — read only</h3>
                    <p style={{ marginTop: -6, color: "#64748b", fontSize: 13 }}>
                      Costs shown include the configured material waste percentage. These validated ring-beam quantities are now combined with the audited wallplate assembly in the live Hipped Lean-To Summary.
                    </p>
                    <div style={{ overflowX: "auto", marginBottom: 18 }}>
                      <table style={{ width: "100%", borderCollapse: "collapse" }}>
                        <thead>
                          <tr>
                            <th style={th}>Summary line</th>
                            <th style={th}>Current qty</th>
                            <th style={th}>Proposed qty</th>
                            <th style={th}>Current order</th>
                            <th style={th}>Proposed order</th>
                            <th style={th}>Current chargeable</th>
                            <th style={th}>Proposed chargeable</th>
                            <th style={th}>Current weight</th>
                            <th style={th}>Proposed weight</th>
                            <th style={th}>Basis</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            ["30×90 PSE", ringBeamSummaryConsolidation.lines.pse30x90],
                            ["9 mm Structural Ply", ringBeamSummaryConsolidation.lines.ply9mm],
                            ["25×50 laths", ringBeamSummaryConsolidation.lines.lath25x50],
                            ["50 mm PIR", ringBeamSummaryConsolidation.lines.pir50],
                          ].map(([label, line]) => (
                            <tr key={label}>
                              <td style={td}><b>{label}</b></td>
                              <td style={td}>{round(line.currentQuantity, 3)} {line.unit}</td>
                              <td style={td}>{round(line.proposedQuantity, 3)} {line.unit}</td>
                              <td style={td}>{line.currentOrderQty ?? "—"}</td>
                              <td style={td}>{line.proposedOrderQty ?? "—"}</td>
                              <td style={td}>£{round(line.currentChargeableCost, 2).toFixed(2)}</td>
                              <td style={td}>£{round(line.proposedChargeableCost, 2).toFixed(2)}</td>
                              <td style={td}>{round(line.currentWeightKg, 2)} kg</td>
                              <td style={td}>{round(line.proposedWeightKg, 2)} kg</td>
                              <td style={td}>{line.note}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </>
                )}

                <div style={{ overflowX: "auto" }}>
                  <table style={{ width: "100%", borderCollapse: "collapse" }}>
                    <thead><tr><th style={th}>Ref</th><th style={th}>Beam</th><th style={th}>Internal</th><th style={th}>External</th><th style={th}>Base</th><th style={th}>Pitch</th><th style={th}>Soffit</th><th style={th}>VFC</th><th style={th}>Upstands</th><th style={th}>Clear bays</th></tr></thead>
                    <tbody>
                      {ringSchedule.members.map((member) => {
                        const beam = member.ringBeam;
                        return <tr key={member.id}>
                          <td style={td}><b>{member.manufactureRef}</b></td><td style={td}>{member.side} ring-beam</td>
                          <td style={td}>{round(beam.internalLengthMM)} mm</td><td style={td}>{round(beam.externalLengthMM)} mm</td>
                          <td style={td}>{round(beam.baseWidthMM, 1)} mm</td><td style={td}>{round(beam.eavesGeometry?.pitchDeg, 1)}°</td>
                          <td style={td}>{round(beam.eavesGeometry?.soffitDepthMM)} mm</td><td style={td}>{round(beam.eavesGeometry?.plumbCutHeightMM)} mm</td>
                          <td style={td}>{beam.upstandCount}</td><td style={td}>{(beam.bayWidthsMM || []).map((width) => round(width)).join(" / ")} mm</td>
                        </tr>;
                      })}
                    </tbody>
                  </table>
                </div>

                <h3>Calculated component usage</h3>
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <tbody>
                    <tr><td style={td}>30×90 PSE continuous ring-beam timber</td><td style={td}>{round(ringSchedule.totals.pse30x90LengthM, 3)} m</td></tr>
                    <tr><td style={td}>9 mm ply base/soffit</td><td style={td}>{round(ringSchedule.totals.ply9BaseAreaM2, 3)} m²</td></tr>
                    <tr><td style={td}>9 mm ply upstands</td><td style={td}>{round(ringSchedule.totals.ply9UpstandAreaM2, 3)} m²</td></tr>
                    <tr><td style={td}>25×50 outer fixing lath</td><td style={td}>{round(ringSchedule.totals.outerFixingLath25x50LengthM, 3)} m</td></tr>
                    <tr><td style={td}>25×50 upstand finishing pieces</td><td style={td}>{round(ringSchedule.totals.finishingLath25x50LengthM, 3)} m</td></tr>
                    <tr><td style={td}>50 mm PIR to upstand faces</td><td style={td}>{round(ringSchedule.totals.pir50AreaM2, 3)} m²</td></tr>
                  </tbody>
                </table>
              </section>
            )}
          </>
        )}
      </main>
    </div>
  );
}
