// src/pages/lean-to/LeanToLanding.jsx
import PlanDiagramHippedLeanTo from "../../components/PlanDiagramHippedLeanTo";
import { calculateHippedLeanToGeometry } from "../../lib/geometry/hippedLeanToGeometry";
import HippedLeanToOptions from "../../components/HippedLeanToOptions";
import { isAdminUser } from "../../lib/userRole";
import { getCustomers } from "../../lib/customers";
import React, { useMemo, useState, useEffect } from "react";
import { getMaterials } from "../../lib/materials";
import { computeTilesLathsBOM } from "../../lib/Calculations/tilesLathsCalc";
//import { computeFasciaSoffitLeanTo } from "../../lib/fasciaSoffitCalc";
//import { computeEdgeTrimsLeanTo } from "../../lib/edgeTrimsCalc";
//import { computeGuttersLeanTo } from "../../lib/guttersCalc";
import PlanDiagramLeanTo from "../../components/PlanDiagramLeanTo";
import { computeLiteSlateLeanTo as computeLiteSlate } from "../../lib/Calculations/liteslateCalc";
//import { computeMiscLeanTo } from "../../lib/miscCalc"; 
import { useLocation, useNavigate } from "react-router-dom";
import NavTabs from "../../components/NavTabs";
import { buildLeanToTotals, buildLeanToQuoteBase } from "../../lib/leanToTotals";
import { getCurrentCustomer } from "../../lib/customers";
import {
  computePricing,
  computeLabourPricing,
  computeDeliveryPricing,
  getLabourPricingConfig,
  getDeliveryPricingConfig,
  getMarkupPricingConfig,
} from "../../lib/pricing";
import {
  saveQuote as saveQuoteToCloud,
  getNextQuoteNumber,
} from "../../lib/quotes";
import TemplateGeometryVisualizer from "../../components/TemplateGeometryVisualizer";
import WallplateGeometryVisualizer from "../../components/WallplateGeometryVisualizer";
import HippedWallplateFrontVisualizer from "../../components/HippedWallplateFrontVisualizer";
import {
  resolveEdgeSupport,
  resolveTwoSidedExternalWidth,
} from "../../lib/geometry/supportGeometry";
import {
  computeLeanToManufactureGeometry,
  solveLeanToPitchForMaximumFinishedHeight,
} from "../../lib/leanToManufactureGeometry";

// adjust path if file structure differs

//const LEAN_TO_STORAGE_KEY = "leanToInputs";

/* ——— styles ——— */
const card = {
  background: "#fff",
  border: "1px solid #e5e7eb",
  borderRadius: 12,
  padding: 12,
};
const grid2 = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))",
  gap: 10,
};
const inputStyle = {
  width: "100%",
  height: 34,
  padding: "5px 8px",
  fontSize: 13,
  border: "1px solid #d1d5db",
  borderRadius: 8,
  boxSizing: "border-box",
};
const h2 = { fontSize: 18, fontWeight: 600, margin: "0 0 8px" };
const primaryBtn = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #0ea5e9",
  background: "#0284c7",
  color: "#fff",
  fontWeight: 600,
};
/*
  const linkBtn = {
  color: "#fff",
  textDecoration: "none",
  padding: "6px 10px",
  borderRadius: 8,
  border: "1px solid rgba(255,255,255,0.15)",
};
*/
// small helpers
const num = (v, f = 0) => (Number.isFinite(Number(v)) ? Number(v) : f);
const round = (v, dp = 0) => {
  const p = 10 ** dp;
  return Math.round((Number(v) || 0) * p) / p;
};

  export default function LeanToLanding() {
const isMobile = window.innerWidth < 600;

const grid2Responsive = {
  display: "grid",
  gridTemplateColumns: isMobile
    ? "1fr 1fr"
    : "repeat(auto-fit, minmax(180px, 1fr))",
  gap: isMobile ? 8 : 10,
};

 // console.log("LEAN_TO_LANDING: RENDERED");

  // Router hooks must be inside the component
  const location = useLocation();
  const navigate = useNavigate();

  // ——— Simple customer inputs ———
  const [widthMM, setWidth]   = useState("");   // internal width
  const [projMM, setProj]     = useState("");   // internal projection
  const [pitchDeg, setPitch]  = useState(15);   // default 15°
  const [
  maximumFinishedHeightMM,
  setMaximumFinishedHeightMM,
] = useState("");
  const [inputsRestored, setInputsRestored] = useState(false);
  const [leftWall, setLeftWall] = useState(false);
  const [rightWall, setRightWall] = useState(false);
  const [leftSupportDepthMM, setLeftSupportDepthMM] = useState(70);
  const [rightSupportDepthMM, setRightSupportDepthMM] = useState(70);
  const [roofStyle, setRoofStyle] = useState(location.state?.roofStyle || "leanTo");
  const [hippedSides, setHippedSides] = useState(location.state?.hippedSides || "both");
  const [leftHip, setLeftHip] = useState(true);
  const [rightHip, setRightHip] = useState(true);
  const [leftHipWidthMM, setLeftHipWidthMM] = useState("1000");
  const [rightHipWidthMM, setRightHipWidthMM] = useState("1000");
  const [leftHipWidthManual, setLeftHipWidthManual] = useState(false);
  const [rightHipWidthManual, setRightHipWidthManual] = useState(false);
  const [requestedLeftSidePitchDeg, setRequestedLeftSidePitchDeg] = useState("");
  const [requestedRightSidePitchDeg, setRequestedRightSidePitchDeg] = useState("");
  const activeHippedSides = leftHip && rightHip ? "both" : leftHip ? "left" : rightHip ? "right" : "none";
  const getDefaultHipWidth = (projection) => {
  const p = Number(projection) || 0;
  if (!p) return 1000;
  return Math.round(p * 0.5);
};


        // ---- react to Materials changes ----
/*const [materialsTick, setMaterialsTick] = useState(0);

useEffect(() => {
  const bump = () => setMaterialsTick((t) => t + 1);

  window.addEventListener("materials_updated", bump);
  window.addEventListener("storage", bump); // cross-tab safety

  return () => {
    window.removeEventListener("materials_updated", bump);
    window.removeEventListener("storage", bump);
  };
}, []);
*/
const [materialsVersion, setMaterialsVersion] = useState(0);

useEffect(() => {
  const handleMaterialsUpdated = () => {
    setMaterialsVersion((v) => v + 1);
  };

  window.addEventListener("materials_updated", handleMaterialsUpdated);

  return () => {
    window.removeEventListener("materials_updated", handleMaterialsUpdated);
  };
}, []);

const m = useMemo(() => getMaterials(), [materialsVersion]);


    // Restore saved Lean-To inputs (if any) when landing on this page
useEffect(() => {
  try {
    const raw = localStorage.getItem("leanToInputs");
    if (!raw) {
  setInputsRestored(true);
  return;
}

    const saved = JSON.parse(raw) || {};

    // Width: prefer internalWidthMM, fall back to widthMM
    const savedWidth =
      saved.internalWidthMM ?? saved.widthMM;
    if (savedWidth !== undefined) {
      setWidth(savedWidth);
    }

    // Projection: prefer internalProjectionMM, fall back to projMM
    const savedProj =
      saved.internalProjectionMM ?? saved.projMM;
    if (savedProj !== undefined) {
      setProj(savedProj);
    }

    // Pitch
    if (saved.pitchDeg !== undefined) {
      setPitch(saved.pitchDeg);
    }

    if (
  saved.maximumFinishedHeightMM !== undefined &&
  saved.maximumFinishedHeightMM !== null
) {
  setMaximumFinishedHeightMM(
    String(saved.maximumFinishedHeightMM)
  );
}

if (saved.roofStyle) {
  setRoofStyle(saved.roofStyle);
}

if (saved.hippedSides) {
  setHippedSides(saved.hippedSides);
}

if (typeof saved.leftHip === "boolean") {
  setLeftHip(saved.leftHip);
}

if (typeof saved.rightHip === "boolean") {
  setRightHip(saved.rightHip);
}

if (saved.leftHipWidthMM !== undefined) {
  setLeftHipWidthMM(saved.leftHipWidthMM);
}

if (saved.rightHipWidthMM !== undefined) {
  setRightHipWidthMM(saved.rightHipWidthMM);
}
if (saved.requestedLeftSidePitchDeg !== undefined) {
  setRequestedLeftSidePitchDeg(
    String(saved.requestedLeftSidePitchDeg)
  );
}

if (saved.requestedRightSidePitchDeg !== undefined) {
  setRequestedRightSidePitchDeg(
    String(saved.requestedRightSidePitchDeg)
  );
}
    // Walls: your stored shape uses left_exposed/right_exposed
if (typeof saved.left_exposed === "boolean") {
  setLeftWall(!saved.left_exposed);
} else if (typeof saved.leftWall === "boolean") {
  setLeftWall(saved.leftWall);
}

if (typeof saved.right_exposed === "boolean") {
  setRightWall(!saved.right_exposed);
} else if (typeof saved.rightWall === "boolean") {
  setRightWall(saved.rightWall);
}

// Restore per-side support depths
if (saved.leftSupportDepthMM !== undefined) {
  setLeftSupportDepthMM(
    Number(saved.leftSupportDepthMM) || 70
  );
}

if (saved.rightSupportDepthMM !== undefined) {
  setRightSupportDepthMM(
    Number(saved.rightSupportDepthMM) || 70
  );
}

if (saved.showQuote) {
  setShowQuote(true);
}
  } catch (e) {
    console.warn("Failed to restore leanToInputs", e);
  } finally {
    setInputsRestored(true);
  }
}, []);


  // Persist current Lean-To inputs, merging into any existing leanToInputs object
useEffect(() => {
  if (!inputsRestored) return;

  try {
    const raw = localStorage.getItem("leanToInputs");
    const existing = raw ? JSON.parse(raw) : {};

    const merged = {
  ...existing,
  internalWidthMM:
    widthMM === "" ? undefined : Number(widthMM),
  internalProjectionMM:
    projMM === "" ? undefined : Number(projMM),

  pitchDeg,

  maximumFinishedHeightMM:
  maximumFinishedHeightMM === ""
    ? null
    : Number(maximumFinishedHeightMM),

  roofStyle,
  hippedSides: activeHippedSides,

  leftHip,
  rightHip,
  leftHipWidthMM,
  rightHipWidthMM,

    requestedLeftSidePitchDeg:
    requestedLeftSidePitchDeg === ""
      ? null
      : Number(requestedLeftSidePitchDeg),

  requestedRightSidePitchDeg:
    requestedRightSidePitchDeg === ""
      ? null
      : Number(requestedRightSidePitchDeg),

  left_exposed: !leftWall,
  right_exposed: !rightWall,

  leftSupportDepthMM,
  rightSupportDepthMM,
};

    localStorage.setItem("leanToInputs", JSON.stringify(merged));
  } catch (e) {
    console.warn("Failed to save leanToInputs", e);
  }
}, [
  inputsRestored,
  widthMM,
  projMM,
  pitchDeg,
  maximumFinishedHeightMM,
  leftWall,
  rightWall,
  roofStyle,
  activeHippedSides,
  leftHip,
  rightHip,
  leftHipWidthMM,
  rightHipWidthMM,
  requestedLeftSidePitchDeg,
  requestedRightSidePitchDeg,
  leftSupportDepthMM,
  rightSupportDepthMM,
]);
useEffect(() => {
  const defaultHip = getDefaultHipWidth(projMM);

  if (!leftHipWidthManual) {
    setLeftHipWidthMM(String(defaultHip));
  }

  if (!rightHipWidthManual) {
    setRightHipWidthMM(String(defaultHip));
  }
}, [
  projMM,
  leftHipWidthManual,
  rightHipWidthManual,
]);

  // Reset Lean-To inputs when arriving from Welcome page with { state: { fresh: true } }
  useEffect(() => {
    if (location.state?.fresh) {
  try {
    // Clear saved inputs so the page starts at defaults
    localStorage.removeItem("leanToInputs");

localStorage.removeItem("summary_exclusions");
window.dispatchEvent(new Event("summary_exclusions_updated"));

localStorage.removeItem("summary_adjustments");
window.dispatchEvent(new Event("summary_adjustments_updated"));

        // Reset local state (blank/default form)
        setWidth("");
        setProj("");
        setPitch(15);
        setLeftWall(false);
        setRightWall(false);
        setRoofStyle(location.state?.roofStyle || "leanTo");
        setHippedSides(location.state?.hippedSides || "both");
        setLeftHipWidthManual(false);
        setRightHipWidthManual(false);
        setLeftHip(true);
        setRightHip(true);
      } catch (err) {
        console.warn("Could not reset Lean-To inputs:", err);
      }

      // Clear the flag so Back/Forward doesn’t retrigger
      navigate(".", { replace: true, state: {} });
    }
    // run once on mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

// ---- clear summary adjustments ----
const clearSummaryAdjustments = () => {
  localStorage.removeItem("summary_adjustments");
  window.dispatchEvent(new Event("summary_adjustments_updated"));
};

  // ---- persist helper ----
const persist = (patch) => {
  let cur = {};
  try {
    cur = JSON.parse(localStorage.getItem("leanToInputs")) || {};
  } catch {}

  const hasChanged = Object.keys(patch || {}).some(
    (key) => cur[key] !== patch[key]
  );

  const next = { ...cur, ...patch };
  localStorage.setItem("leanToInputs", JSON.stringify(next));

  if (hasChanged) clearSummaryAdjustments();
};

  const [eavesOverhangMM, setEavesOverhang] = useState(150); // soffit depth (front)
  const [leftOverhangMM, setLeftOverhang] = useState("");    // optional side overhangs
  const [rightOverhangMM, setRightOverhang] = useState("");
const [summaryAdjustmentTick, setSummaryAdjustmentTick] = useState(0);
  // Gutters
  const [gutterProfile, setGutterProfile] = useState("square"); // 'square' | 'round' | 'ogee'
  const [gutterOutlet,  setGutterOutlet]  = useState("left");   // 'left' | 'right' | 'center' | 'both' | 'none'
  const [gutterColor,   setGutterColor]   = useState("black");  // 'black' | 'white' | 'anthracite' | 'brown'

  // Tiles & plastics (cosmetic choices here)
  // ✅ Persist selected tile system across pages (init from localStorage)
  const [tileSystem, setTileSystem] = useState(() => {
    return localStorage.getItem("tl_tile_system") ?? "britmet";
  });
  const minTilePitchDeg = tileSystem === "liteslate" ? 12 : 15;
  const maximumHeightIsActive =
  roofStyle !== "hippedLeanTo" &&
  maximumFinishedHeightMM !== "";

const maximumHeightPitchSolutionDeg = useMemo(() => {
  if (!maximumHeightIsActive) {
    return null;
  }

  return solveLeanToPitchForMaximumFinishedHeight({
    internalProjectionMM: num(projMM),
    maximumFinishedHeightMM:
      num(maximumFinishedHeightMM),
  });
}, [
  maximumHeightIsActive,
  projMM,
  maximumFinishedHeightMM,
]);

const maximumHeightIsImpossible =
  maximumHeightIsActive &&
  maximumHeightPitchSolutionDeg === null;

useEffect(() => {
  if (
    !maximumHeightIsActive ||
    maximumHeightPitchSolutionDeg === null
  ) {
    return;
  }

  // Round downward so the finished roof cannot
  // accidentally exceed the entered restriction.
  const restrictedPitchDeg =
    Math.floor(
      (maximumHeightPitchSolutionDeg + 0.000001) * 10
    ) / 10;

  if (
    Number(pitchDeg) !== restrictedPitchDeg
  ) {
    setPitch(restrictedPitchDeg);

    persist({
      pitchDeg: restrictedPitchDeg,
      pitch: restrictedPitchDeg,
      maximumFinishedHeightMM:
        Number(maximumFinishedHeightMM),
    });
  }
}, [
  maximumHeightIsActive,
  maximumHeightPitchSolutionDeg,
  maximumFinishedHeightMM,
  pitchDeg,
]);


const hippedGeom =
  roofStyle === "hippedLeanTo"
    ? calculateHippedLeanToGeometry({
        widthMM: num(widthMM),
        projectionMM: num(projMM),
        pitchDeg: num(pitchDeg, 15),
        soffitDepthMM: num(eavesOverhangMM),
        materials: m,

        hippedSides: activeHippedSides,
        leftHipWidthMM: num(leftHipWidthMM, 1000),
        rightHipWidthMM: num(rightHipWidthMM, 1000),

        requestedLeftSidePitchDeg:
  requestedLeftSidePitchDeg === ""
    ? null
    : Number(requestedLeftSidePitchDeg),

requestedRightSidePitchDeg:
  requestedRightSidePitchDeg === ""
    ? null
    : Number(requestedRightSidePitchDeg),

        requestedLeftSidePitchDeg:
  requestedLeftSidePitchDeg === ""
    ? null
    : Number(requestedLeftSidePitchDeg),

requestedRightSidePitchDeg:
  requestedRightSidePitchDeg === ""
    ? null
    : Number(requestedRightSidePitchDeg),

        leftWall,
        rightWall,
        leftOverhangMM: num(leftOverhangMM, 0),
        rightOverhangMM: num(rightOverhangMM, 0),
      })
    : null;

const leftSidePitchDeg =
  hippedGeom?.leftSidePitchDeg ?? 0;

const rightSidePitchDeg =
  hippedGeom?.rightSidePitchDeg ?? 0;

const leftHipPitchTooLow =
  roofStyle === "hippedLeanTo" &&
  leftHip &&
  leftSidePitchDeg > 0 &&
  leftSidePitchDeg < minTilePitchDeg;

const rightHipPitchTooLow =
  roofStyle === "hippedLeanTo" &&
  rightHip &&
  rightSidePitchDeg > 0 &&
  rightSidePitchDeg < minTilePitchDeg;

  const [tileColor, setTileColor]   = useState("Titanium");
  const [plasticsColor, setPlasticsColor] = useState("White");

  // Exposed sides (persisted via leanToInputs; also synced with wall checkboxes)
  const [leftSideExposed, setLeftSideExposed] = useState(() => {
    const stored = localStorage.getItem("leanToInputs");
    if (!stored) return true;
    try {
      const parsed = JSON.parse(stored);
      return parsed.left_exposed ?? true;   // legacy key
    } catch {
      return true;
    }
  });
  const [rightSideExposed, setRightSideExposed] = useState(() => {
    const stored = localStorage.getItem("leanToInputs");
    if (!stored) return true;
    try {
      const parsed = JSON.parse(stored);
      return parsed.right_exposed ?? true;  // legacy key
    } catch {
      return true;
    }
  });

  // Quote UI
  const [showQuote, setShowQuote] = useState(false);
  const [quoteRef, setQuoteRef] = useState("");
  const [deliveryPostcode, setDeliveryPostcode] = useState("");
  const [deliveryDistanceMiles, setDeliveryDistanceMiles] = useState(0);
  const [deliveryLoading, setDeliveryLoading] = useState(false);
  const [deliveryError, setDeliveryError] = useState("");
  const [quoteError, setQuoteError] = useState("");
  const [selectedCustomerId, setSelectedCustomerId] = useState(() => {
  const current = getCurrentCustomer();
  return current?.id || "retail";
});

const [customers, setCustomers] = useState([]);

useEffect(() => {
  let alive = true;

  async function loadCustomers() {
    const loadedCustomers = await getCustomers();

    if (alive) {
      setCustomers(Array.isArray(loadedCustomers) ? loadedCustomers : []);
    }
  }

  loadCustomers();

  window.addEventListener("quoteapp_customers_updated", loadCustomers);

  return () => {
    alive = false;
    window.removeEventListener("quoteapp_customers_updated", loadCustomers);
  };
}, []);
const isAdmin = isAdminUser();
const selectedCustomer =
  selectedCustomerId !== "retail"
    ? customers.find((c) => c.id === selectedCustomerId) || null
    : null;
    const discountPct = selectedCustomer
  ? Number(selectedCustomer.discountPct || 0)
  : 0;
  // ---- tile colour lists (per system) ----
  const britmetColours = [
    "Titanium",
    "Raven",
    "Bramble Brown",
    "Rustic Brown",
    "Rustic Terracotta",
    "Smoked Oak",
    "Rustic Red",
    "Tartan Green",
  ];
  const liteslateColours = [
    "Slate",
    "Ash",
    "Charcoal",
    "Oak",
    "Amethyst",
    "Sunset",
    "Sunshine",
  ];

  // If the user switches system and the current colour isn't valid, snap to first
  useEffect(() => {
    const list = tileSystem === "liteslate" ? liteslateColours : britmetColours;
    if (!list.includes(tileColor)) setTileColor(list[0]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tileSystem, tileColor]);

  // ✅ Save tile system whenever it changes
  useEffect(() => {
    localStorage.setItem("tl_tile_system", String(tileSystem).toLowerCase());
  }, [tileSystem]);

  const loadSummaryExclusions = () => {
  try {
    return JSON.parse(localStorage.getItem("summary_exclusions") || "{}");
  } catch {
    return {};
  }
};
const loadSummaryAdjustments = () => {
  try {
    return JSON.parse(localStorage.getItem("summary_adjustments") || "{}");
  } catch {
    return {};
  }
};

const loadSummaryExclusionValues = () => {
  try {
    return JSON.parse(localStorage.getItem("summary_exclusion_values") || "{}");
  } catch {
    return {};
  }
};

const loadSummaryAdjustmentValues = () => {
  try {
    return JSON.parse(localStorage.getItem("summary_adjustment_values") || "{}");
  } catch {
    return {};
  }
};
useEffect(() => {
  const handleSummaryAdjustmentsUpdated = () => {
    setSummaryAdjustmentTick((v) => v + 1);
  };

  window.addEventListener(
    "summary_adjustments_updated",
    handleSummaryAdjustmentsUpdated
  );

  return () => {
    window.removeEventListener(
      "summary_adjustments_updated",
      handleSummaryAdjustmentsUpdated
    );
  };
}, []);

  // ——— Persist to match the rest of the app ———
const persistInputs = (opts = {}) => {
  const payload = {

    // core sizes
    internalWidthMM: widthMM === "" ? null : Number(widthMM),
    internalProjectionMM: projMM === "" ? null : Number(projMM),
    pitchDeg: Number(pitchDeg),
    maximumFinishedHeightMM:
  maximumFinishedHeightMM === ""
    ? null
    : Number(maximumFinishedHeightMM),
    selectedCustomerId,
    roofStyle,
    hippedSides: activeHippedSides,
    leftHip,
    rightHip,

    leftHipWidthMM: Number(leftHipWidthMM || 0),
    rightHipWidthMM: Number(rightHipWidthMM || 0),

    requestedLeftSidePitchDeg:
  requestedLeftSidePitchDeg === ""
    ? null
    : Number(requestedLeftSidePitchDeg),

requestedRightSidePitchDeg:
  requestedRightSidePitchDeg === ""
    ? null
    : Number(requestedRightSidePitchDeg),


    // customer / reference
    quoteRef,
    customerName: selectedCustomerId === "retail" ? "Retail" : selectedCustomer?.name || "",
    discountPct,

    // fascia/soffit + overhangs
    soffit_mm: Number(eavesOverhangMM),
    left_overhang_mm: Number(leftOverhangMM || 0),
    right_overhang_mm: Number(rightOverhangMM || 0),

    // exposed/wall flags — store with legacy keys for compatibility
    left_exposed: leftSideExposed,
    right_exposed: rightSideExposed,

    // per-side support depths
    leftSupportDepthMM: Number(leftSupportDepthMM || 70),

    rightSupportDepthMM: Number(rightSupportDepthMM || 70),

    // defaults other pages expect
    gauge_mm: 250,
    tile_cover_w_mm: m.tile_britmet_cover_w_mm ?? 1231,
    eaves_overhang_mm: 50,
    plastics_finish:
      String(plasticsColor).toLowerCase() === "white" ? "white" : "foiled",
    vent_method: "factory",
    side_frame_thickness_mm: m.side_frame_thickness_mm ?? 70,
    fascia_lip_mm: m.fascia_lip_mm ?? 25,
    frame_on_mm: m.frame_on_mm ?? 70,

   

    // gutters
    gutter_profile: gutterProfile,
    gutter_outlet: gutterOutlet,
    gutter_color: gutterColor,

    // cosmetic choices
tile_system: tileSystem,
tile_color: tileColor,
plastics_color: plasticsColor,

// delivery
deliveryPostcode: opts.deliveryPostcode ?? deliveryPostcode,
deliveryDistanceMiles:
  opts.deliveryDistanceMiles ?? Number(deliveryDistanceMiles || 0),

// NEW: whether the quote/plan panel is currently shown
showQuote: opts.overrideShowQuote ?? showQuote,
  };

  localStorage.setItem("leanToInputs", JSON.stringify(payload));
  window.dispatchEvent(new Event("leanToInputs_updated"));
};


  // LOAD once on mount
  useEffect(() => {
    try {
      const s = localStorage.getItem("leanToInputs");
      if (s) {
        const q = JSON.parse(s);

        // core sizes
        if (q.internalWidthMM != null)      setWidth(String(Number(q.internalWidthMM)));
        if (q.internalProjectionMM != null) setProj(String(Number(q.internalProjectionMM)));
        if (q.pitchDeg != null)             setPitch(Number(q.pitchDeg));
        if (q.maximumFinishedHeightMM != null) {
  setMaximumFinishedHeightMM(
    String(q.maximumFinishedHeightMM)
  );
}
        if (q.soffit_mm != null)            setEavesOverhang(Number(q.soffit_mm));
        if (q.left_overhang_mm != null)     setLeftOverhang(String(q.left_overhang_mm));
        if (q.right_overhang_mm != null)    setRightOverhang(String(q.right_overhang_mm));

// walls — prefer new keys, fall back to legacy exposed flags
if ("left_wall_present" in q) {
  setLeftWall(!!q.left_wall_present);
} else if ("left_exposed" in q) {
  setLeftWall(!q.left_exposed);
}

if ("right_wall_present" in q) {
  setRightWall(!!q.right_wall_present);
} else if ("right_exposed" in q) {
  setRightWall(!q.right_exposed);
}

if (q.leftSupportDepthMM != null) {
  setLeftSupportDepthMM(
    Number(q.leftSupportDepthMM) || 70
  );
}

if (q.rightSupportDepthMM != null) {
  setRightSupportDepthMM(
    Number(q.rightSupportDepthMM) || 70
  );
}

// gutters
if (q.gutter_profile) setGutterProfile(String(q.gutter_profile));
if (q.gutter_outlet) setGutterOutlet(String(q.gutter_outlet));
if (q.gutter_color) setGutterColor(String(q.gutter_color));

// cosmetics
if (q.tile_system) setTileSystem(String(q.tile_system));
if (q.tile_color) setTileColor(String(q.tile_color));
if (q.plastics_color) setPlasticsColor(String(q.plastics_color));

// customer
if (q.selectedCustomerId) {
  setSelectedCustomerId(String(q.selectedCustomerId));
}
if (q.quoteRef) setQuoteRef(String(q.quoteRef));

// delivery
if (q.deliveryPostcode) {
  setDeliveryPostcode(String(q.deliveryPostcode));
}

if (q.deliveryDistanceMiles != null) {
  setDeliveryDistanceMiles(Number(q.deliveryDistanceMiles || 0));
}
      }
    } catch (e) {
      console.warn("Failed to load leanToInputs", e);
    }

    // If a subpage asked us to show the quote on return
    if (localStorage.getItem("auto_show_quote") === "1") {
      setShowQuote(true);
      localStorage.removeItem("auto_show_quote");
    }
  }, []);

  // Keep exposed-side flags in sync with the “wall present?” checkboxes
  useEffect(() => {
    setLeftSideExposed(!leftWall);
    setRightSideExposed(!rightWall);
  }, [leftWall, rightWall]);

// ===============================
// SINGLE SOURCE OF TRUTH TOTALS
// (same pipeline as Summary)
// ===============================

const exclusions = useMemo(() => ({}), []); // Landing = no exclusions (customer-facing)

const totalsInput = useMemo(
  () => ({
    widthMM: num(widthMM, 0),
    projMM: num(projMM, 0),
    pitchDeg: num(pitchDeg, 15),

    leftWall,
    rightWall,

    eavesOverhangMM: num(eavesOverhangMM, 150),
    leftOverhangMM: num(leftOverhangMM, 0),
    rightOverhangMM: num(rightOverhangMM, 0),

    tileSystem,
    plasticsColor,
    gutterProfile,
    gutterOutlet,
    gutterColor,
  }),
  [
    widthMM,
    projMM,
    pitchDeg,
    leftWall,
    rightWall,
    eavesOverhangMM,
    leftOverhangMM,
    rightOverhangMM,
    tileSystem,
    plasticsColor,
    gutterProfile,
    gutterOutlet,
    gutterColor,
  ]
);

/*const t = useMemo(
  () => buildLeanToTotals(totalsInput, exclusions),
  [totalsInput, exclusions]
);
*/
const summaryExclusions = loadSummaryExclusions();

const quoteBase = useMemo(
  () => buildLeanToQuoteBase(totalsInput, summaryExclusions),
  [totalsInput, summaryExclusions]
);

const totals = useMemo(
  () => buildLeanToTotals(totalsInput, summaryExclusions),
  [totalsInput, summaryExclusions]
);

const summaryAdjustments = loadSummaryAdjustments();
const summaryAdjustmentValues = loadSummaryAdjustmentValues();
const summaryExclusionValues = loadSummaryExclusionValues();

const adjustmentDelta = [
  ...Object.values(summaryAdjustmentValues),
  ...Object.values(summaryExclusionValues),
].reduce((sum, value) => {
  const n = Number(value);
  return Number.isFinite(n) ? sum + n : sum;
}, 0);


const pricing = useMemo(() => {
  const labourConfig = getLabourPricingConfig();

  const labourFeatures = {
    roofVent: false,
    fixedUnit: false,
    reinforcedRingBeam: false,
  };
const areaM2 =
  (Number(widthMM || 0) * Number(projMM || 0)) / 1_000_000;

let baseDays = 1;

if (areaM2 > 8.75) {
  baseDays = 1 + ((areaM2 - 8.75) * 0.15);
}

baseDays = Math.min(baseDays, 3);
baseDays = Math.ceil(baseDays * 10) / 10;

const savedInputs = (() => {
  try {
    return JSON.parse(localStorage.getItem("leanToInputs") || "{}");
  } catch {
    return {};
  }
})();

const labourDaysOverride = Number(savedInputs.labourDaysOverride);

const effectiveMinimumDays =
  Number.isFinite(labourDaysOverride) && labourDaysOverride > 0
    ? labourDaysOverride
    : Math.max(Number(labourConfig.minimumDays || 1), baseDays);

const labourConfigAdjusted = {
  ...labourConfig,
  minimumDays: effectiveMinimumDays,
};
  const labour = computeLabourPricing({
    widthMM: Number(widthMM || 0),
    projectionMM: Number(projMM || 0),
    tileSystem,
    config: labourConfigAdjusted,
    features: labourFeatures,
  });

  const deliveryConfig = getDeliveryPricingConfig();

const deliveryMilesForPricing =
  Number(deliveryDistanceMiles || 0) ||
  Number(selectedCustomer?.defaultDeliveryMilesOneWay || 0);

const deliveryResult = computeDeliveryPricing(
  deliveryMilesForPricing,
  deliveryConfig
);

const markupConfig = getMarkupPricingConfig();
console.log("DO_PRICE_DEBUG", {
  selectedCustomerId,
  selectedCustomer,
  discountPct,
  materialsCostForPricing: quoteBase.materialsCostForPricing,
  adjustmentDelta,
  deliveryDistanceMiles,
});
return computePricing(
  quoteBase.materialsCostForPricing + adjustmentDelta,
  {
    ...m,
    profit_pct: markupConfig.profitPct,
  },
  {
  labourCost: labour.labourCost,
  deliveryCost: deliveryResult.deliveryCost,
  discountPct,
}
);
}, [
  quoteBase.materialsCostForPricing,
  adjustmentDelta,
  summaryAdjustmentTick,
  m,
  widthMM,
  projMM,
  tileSystem,
  deliveryDistanceMiles,
  discountPct,
  selectedCustomer,
]);
/*console.log("PRICING_COMPARE", {
  page: "LeanToLanding",
  materialsCostForPricing: quoteBase?.materialsCostForPricing,
  delivery_flat: m?.delivery_flat,
  profit_pct: m?.profit_pct,
  vat_rate: m?.vat_rate,
  net: pricing?.net,
  vat: pricing?.vat,
  gross: pricing?.gross,

  // geometry + options that MUST match Summary
  widthMM: totalsInput?.widthMM,
  projMM: totalsInput?.projMM,
  pitchDeg: totalsInput?.pitchDeg,
  leftWall: totalsInput?.leftWall,
  rightWall: totalsInput?.rightWall,
  eavesOverhangMM: totalsInput?.eavesOverhangMM,
  leftOverhangMM: totalsInput?.leftOverhangMM,
  rightOverhangMM: totalsInput?.rightOverhangMM,
  tileSystem: totalsInput?.tileSystem,
  gutterProfile: totalsInput?.gutterProfile,
  gutterOutlet: totalsInput?.gutterOutlet,
  gutterColor: totalsInput?.gutterColor,
});
*/

  // ❌ Do NOT auto-save on every input change – it wipes leanToInputs when revisiting the page
/*
useEffect(() => {
  persistInputs();
  // eslint-disable-next-line react-hooks/exhaustive-deps
}, [
  widthMM, projMM, pitchDeg,
  leftWall, rightWall,
  eavesOverhangMM, leftOverhangMM, rightOverhangMM,
  gutterProfile, gutterOutlet, gutterColor,
  tileSystem, tileColor, plasticsColor,
]);
*/


// ——— Derived external sizes ———
const extWidthMM = useMemo(() => {
  const iw = num(widthMM);

  const defaultSupportDepthMM =
    num(m.side_frame_thickness_mm ?? 70);

  const fasciaLipMM =
    num(m.fascia_lip_mm ?? 25);

  const leftSupport =
    resolveEdgeSupport({
      type: leftWall ? "wall" : "frame",
      depthMM: leftSupportDepthMM,
      defaultDepthMM: defaultSupportDepthMM,
    });

  const rightSupport =
    resolveEdgeSupport({
      type: rightWall ? "wall" : "frame",
      depthMM: rightSupportDepthMM,
      defaultDepthMM: defaultSupportDepthMM,
    });

  const resolved =
    resolveTwoSidedExternalWidth({
      internalWidthMM: iw,

      leftSupport,
      rightSupport,

      leftOverhangMM:
        num(leftOverhangMM, 0),

      rightOverhangMM:
        num(rightOverhangMM, 0),

      fasciaLipMM,
    });

  return resolved.externalWidthMM;
}, [
  widthMM,
  leftWall,
  rightWall,
  leftOverhangMM,
  rightOverhangMM,
  leftSupportDepthMM,
  rightSupportDepthMM,
  m,
]);



  const extProjectionMM = useMemo(() => {
    const ip      = num(projMM);
    const soff    = num(eavesOverhangMM);
    const frameOn = num(m.frame_on_mm ?? 70);
    return ip + soff + frameOn;
  }, [projMM, eavesOverhangMM, m]);

  const theta = (num(pitchDeg) * Math.PI) / 180;
  const slopeMM = extProjectionMM / Math.cos(theta);
  const riseMM = extProjectionMM * Math.tan(theta);

const leanToManufactureGeom = useMemo(
  () =>
    computeLeanToManufactureGeometry({
      internalProjectionMM: num(projMM),
      pitchDeg: num(pitchDeg, 15),
      soffitDepthMM: num(eavesOverhangMM, 150),
      frameThicknessMM:
        num(m.side_frame_thickness_mm, 70),
    }),
  [
    projMM,
    pitchDeg,
    eavesOverhangMM,
    m,
  ]
);

const externalFinishedHeightMM =
  leanToManufactureGeom
    .calculatedMaximumFinishedHeightMM;

  // ——— Minimal BOMs ———

  const tilesBom = useMemo(() => {
    // If LiteSlate selected, use the LiteSlate calculator
    if (String(tileSystem).toLowerCase() === "liteslate" && typeof computeLiteSlate === "function") {
      return computeLiteSlate(
        {
          run_mm: extWidthMM,
          projection_mm: extProjectionMM,
          pitch_deg: pitchDeg,
        },
        m
      );
    }

    // Default: Britmet tiles & laths calculator
    return computeTilesLathsBOM(
      {
        run_mm: extWidthMM,
        // projection_mm: extProjectionMM, // ❌ keep omitted to avoid double-deriving
        slope_mm: slopeMM,                 // ✅ use single slope basis
        pitch_deg: pitchDeg,
        eaves_overhang_mm: 50,
        leftSide: leftSideExposed ? "exposed" : "wall",
        rightSide: rightSideExposed ? "exposed" : "wall",
        waste_pct: 5,
        gauge_mm: m.tile_britmet_gauge_mm ?? 250,
        cover_width_mm: m.tile_britmet_cover_w_mm ?? 1231,
      },
      m
    );
  }, [
    tileSystem,
    extWidthMM,
    extProjectionMM,
    slopeMM,
    pitchDeg,
    leftSideExposed,
    rightSideExposed,
    m,
  ]);

  /*const plastics = useMemo(
  () =>
    computeFasciaSoffitLeanTo(
      {
        run_mm: extWidthMM,
        pitch_deg: pitchDeg,
        soffit_requested_mm: eavesOverhangMM,
        slope_mm: slopeMM,
        projection_mm: extProjectionMM,

        // old names (if fasciaSoffitCalc ever used them)
        leftSideExposed,
        rightSideExposed,

        // 👇 names fasciaSoffitCalc *does* read
        left_exposed: leftSideExposed,
        right_exposed: rightSideExposed,

        // pricing band: white vs foiled
        finish:
          String(plasticsColor).toLowerCase() === "white"
            ? "white"
            : "foiled",

        // NEW: actual visible colour name for labels
        plastics_color: plasticsColor,

        vent_method: "factory",
      },
      m
    ),
  [
    extWidthMM,
    pitchDeg,
    eavesOverhangMM,
    leftSideExposed,
    rightSideExposed,
    slopeMM,
    extProjectionMM,
    plasticsColor,
    m,
  ]
);

  const gutters = useMemo(
    () =>
      computeGuttersLeanTo(
        {
          run_mm: extWidthMM,
          profile: gutterProfile,
          outlet: gutterOutlet,
          color: gutterColor,
        },
        m
      ),
    [extWidthMM, gutterProfile, gutterOutlet, gutterColor, m]
  );

  // ✅ Edge trims (dry verge etc.) — works for Britmet & LiteSlate
  const edgeTrims = useMemo(() => {
    return computeEdgeTrimsLeanTo(
      {
        ext_width_mm: extWidthMM,
        ext_projection_mm: extProjectionMM,
        pitch_deg: pitchDeg,
        // slope_mm: slopeMM, // optional

        leftSide: leftSideExposed ? "exposed" : "wall",
        rightSide: rightSideExposed ? "exposed" : "wall",
        tileSystem: String(tileSystem).toLowerCase(),
        finish: String(plasticsColor).toLowerCase() === "white" ? "white" : "foiled",
      },
      m
    );
  }, [extWidthMM, extProjectionMM, pitchDeg, leftSideExposed, rightSideExposed, tileSystem, plasticsColor, m]);
*/
// --- Build a tile total hint for misc (so tile screws use real tile count) ---
const tilesLineForHint =
  (tilesBom?.lines || []).find(r =>
    /tiles/i.test(String(r.key || r.label || ""))) || null;

const tilesTotalHintRaw =
  tilesBom?.derived?.tiles_total ??
  tilesLineForHint?.qty ??
  tilesLineForHint?.qtyDisplay;

const tilesTotalHint = Number(tilesTotalHintRaw);

// --- Compute Misc (breather, slab, SuperQuilt, fixings etc.) ---
/*
const misc = React.useMemo(() => {
  return computeMiscLeanTo(
    {
      tile_system: tileSystem,          // "britmet" or "liteslate"
      pitchDeg,                         // lets misc pick LiteSlate density bands
      internalWidthMM: Number(widthMM) || 0,
      internalProjectionMM: Number(projMM) || 0,
      tiles_total_hint: Number.isFinite(tilesTotalHint) ? tilesTotalHint : undefined,
    },
    m
  );
  
}, [tileSystem, pitchDeg, widthMM, projMM, tilesTotalHint, m]);
*/

// Can we generate a quote yet?

const missingWidth = !Number(widthMM);
const missingProjection = !Number(projMM);
const missingPostcode = !isAdmin && !String(deliveryPostcode || "").trim();

const hasDeliveryPostcode = !missingPostcode;

const canQuote =
  !missingWidth &&
  !missingProjection &&
  hasDeliveryPostcode;

const requiredInputStyle = {
  borderColor: "#b91c1c",
  background: "#fef2f2",
};

const lookupDeliveryDistance = async () => {
  const postcode = String(deliveryPostcode || "").trim(); 

  if (!postcode) {
    setDeliveryDistanceMiles(0);
    setDeliveryError("");
    return;
  }

  setDeliveryLoading(true);
  setDeliveryError("");

  try {
    const res = await fetch("/api/delivery-distance", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        destinationPostcode: postcode,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data?.error || "Could not calculate delivery distance");
    }

    const miles = Number(data.distanceMiles || 0);
setDeliveryDistanceMiles(miles);

persistInputs({
  deliveryPostcode: postcode,
  deliveryDistanceMiles: miles,
});
return miles;
  } catch (err) {
    setDeliveryDistanceMiles(0);
    setDeliveryError(err.message || "Delivery lookup failed");
  } finally {
    setDeliveryLoading(false);
  }
};

  const onGetQuote = async () => {
  setQuoteError("");

  if (!Number(widthMM) || !Number(projMM)) {
    setQuoteError("Please enter both width and projection before getting a quote.");
    return;
  }

  let miles = Number(deliveryDistanceMiles || 0);

const customerDefaultMiles = Number(
  selectedCustomer?.defaultDeliveryMilesOneWay || 0
);

if (!isAdmin && !String(deliveryPostcode || "").trim() && !customerDefaultMiles) {
  setQuoteError("Please enter a delivery postcode before getting a quote.");
  return;
}

if (String(deliveryPostcode || "").trim()) {
  miles = await lookupDeliveryDistance();
} else if (customerDefaultMiles) {
  miles = customerDefaultMiles;
}

// Save inputs AND the fact that the quote/diagram is visible
persistInputs({
  overrideShowQuote: true,
  deliveryPostcode: String(deliveryPostcode || "").trim(),
  deliveryDistanceMiles: miles,
});

setShowQuote(true);

  setTimeout(() => {
    const el = document.getElementById("quote-result");
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  }, 0);
};


  const resetAll = () => {
    // clear UI
    setWidth("");
    setProj("");
    setPitch(15);
    setLeftWall(false);
    setRightWall(false);

    setLeftSupportDepthMM(70);
    setRightSupportDepthMM(70);

    setRoofStyle(location.state?.roofStyle || roofStyle || "leanTo");
    setHippedSides(location.state?.hippedSides || "both");

    setLeftHip(true);
    setRightHip(true);
    setLeftHipWidthManual(false);
    setRightHipWidthManual(false);
    setLeftHipWidthMM("1000");
    setRightHipWidthMM("1000");
    setRequestedLeftSidePitchDeg("");
    setRequestedRightSidePitchDeg("");
    setEavesOverhang(150);
    setLeftOverhang("");
    setRightOverhang("");

    // gutters
    setGutterProfile("square");
    setGutterOutlet("left");
    setGutterColor("black");

    // tiles/plastics
    setTileSystem("britmet");
    setTileColor("charcoal");
    setPlasticsColor("white");

    setQuoteRef("");
    setShowQuote(false);
    setSelectedCustomerId("retail");

    setDeliveryPostcode("");
    setDeliveryDistanceMiles(0);
    setDeliveryError("");

    // clear stored in-progress quote
    localStorage.removeItem("leanToInputs");
    localStorage.removeItem("summary_exclusions");
    window.dispatchEvent(new Event("summary_exclusions_updated"));
    localStorage.removeItem("summary_adjustments");
    window.dispatchEvent(new Event("summary_adjustments_updated"));
  };

  const saveQuote = async () => {
  const manualReference = (quoteRef || "").trim();
const nextQuoteNumber = await getNextQuoteNumber();
if (!isAdmin && !manualReference) {
  alert("Please enter a customer reference before saving.");
  return;
}

  if (!canQuote) {
    alert("Please enter width and projection before saving.");
    return;
  }

  const payload = {
  widthMM,
  projMM,
  pitchDeg,

  roofStyle,
  hippedSides: activeHippedSides,
  leftHip,
  rightHip,
  leftHipWidthMM: Number(leftHipWidthMM || 0),
  rightHipWidthMM: Number(rightHipWidthMM || 0),

  requestedLeftSidePitchDeg:
    requestedLeftSidePitchDeg === ""
      ? null
      : Number(requestedLeftSidePitchDeg),

  requestedRightSidePitchDeg:
    requestedRightSidePitchDeg === ""
      ? null
      : Number(requestedRightSidePitchDeg),

  leftWall,
  rightWall,

  eavesOverhangMM,
  leftOverhangMM,
  rightOverhangMM,

  tileSystem,
  tileColor,

  plasticsColor,

  gutterProfile,
  gutterColor,
  gutterOutlet,

  selectedCustomerId,

  deliveryPostcode,
  deliveryDistanceMiles,

  quoteRef: manualReference,
};

  const customerForQuote = selectedCustomer || getCurrentCustomer();

  const isUuid = (value) =>
    /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(
      String(value || "")
    );

  const summary = {
    internalWidthMM: Number(widthMM),
    internalProjectionMM: Number(projMM),
    pitchDeg,
    leftWall,
    rightWall,
    eavesOverhangMM: Number(eavesOverhangMM),
    leftOverhangMM: Number(leftOverhangMM || 0),
    rightOverhangMM: Number(rightOverhangMM || 0),
    tileSystem,
    tileColor,
    plasticsColor,
    gutterProfile,
    gutterColor,
    gutterOutlet,
    extWidthMM: Math.round(extWidthMM),
    extProjectionMM: Math.round(extProjectionMM),
    riseMM: Math.round(riseMM),
    net: Number((pricing.net ?? 0).toFixed(2)),
    gross: Number((pricing.gross ?? 0).toFixed(2)),
  };

  const record = {
    quote_number: nextQuoteNumber,
manual_reference: manualReference,
    customer_id:
      customerForQuote && isUuid(customerForQuote.id)
        ? customerForQuote.id
        : null,
    customer_name: customerForQuote?.name || "",
    roof_style: "lean-to",
    status: "quote",
    inputs_json: payload,
    pricing_json: {
      net: Number((pricing.net ?? 0).toFixed(2)),
      vat: Number((pricing.vat ?? 0).toFixed(2)),
      gross: Number((pricing.gross ?? 0).toFixed(2)),
      summary,
    },
    materials_snapshot_json: getMaterials(),
  };

  const saved = await saveQuoteToCloud(record);

  if (!saved) {
    alert("Quote was not saved. Check the console for details.");
    return;
  }

  alert(`Quote ${nextQuoteNumber} saved.`);
};
  /*
const manufactureGeom = useMemo(
  () =>
    computeLeanToManufactureGeometry({
      internalProjectionMM: Number(projMM || 0),
      pitchDeg: Number(pitchDeg || 15),
      soffitDepthMM: Number(eavesOverhangMM ?? 150),

      frameThicknessMM: 70,
      soffitBoardThicknessMM: 10,
      plyThicknessMM: 9,
      lathThicknessMM: 25,

      fasciaStockSizesMM: [200, 225, 250, 300, 400],
    }),
  [projMM, pitchDeg, eavesOverhangMM]
);
*/
const demoBase = tileSystem === "liteslate" ? 450 : 110;
const demoPct = tileSystem === "liteslate" ? 0.235 : 0.525;

const demoProfit = demoBase + (pricing.net ?? 0) * demoPct;
const demoNet = (pricing.net ?? 0) + demoProfit;
const demoVat = demoNet * (pricing.vatRate ?? 0);
const demoGross = demoNet + demoVat;

const displayExtWidthMM =
  roofStyle === "hippedLeanTo" && hippedGeom
    ? hippedGeom.externalWidthMM
    : extWidthMM;

const displayExtProjectionMM =
  roofStyle === "hippedLeanTo" && hippedGeom
    ? hippedGeom.externalProjectionMM
    : extProjectionMM;
    
  return (
    <div className="min-h-screen" style={{ fontFamily: "Inter, system-ui, Arial" }}>
<NavTabs />

      {/* Page body */}
      <div style={{ maxWidth: 1100, margin: "0 auto", padding: 16 }}>

        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, margin: "12px 0 8px" }}>
          <img src="/logo.png" alt="Timberlite" style={{ height: 38 }} onError={(e) => { e.currentTarget.style.display = "none"; }} />
          <h1 style={{ fontSize: 24, fontWeight: 700, margin: 0 }}>
  Timberlite {roofStyle === "hippedLeanTo" ? "Hipped Lean-To" : "Lean-To"}
</h1>
        </div>
        <p style={{ color: "#555", marginTop: 0, marginBottom: 14 }}>
          Enter your sizes and options below. We’ll show a plan preview and your price. 
          Frame thickness is defaulted to 70mm, please confirm this when ordering.
        </p>

        {/* Inputs card */}
        <div style={card}>
          <div style={grid2Responsive}>
            <label>Width (internal, mm)
              <input
                type="number"
                value={widthMM}
                placeholder="e.g. 3500"
                onChange={(e) => {
  setWidth(e.target.value);
  persist({ width: e.target.value });
}}
                style={{
  ...inputStyle,
  ...(missingWidth && quoteError ? requiredInputStyle : {}),
}}
              />
            </label>

            <label>Projection (internal, mm)
              <input
                type="number"
                value={projMM}
                placeholder="e.g. 2500"
                onChange={(e) => {setProj(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={{
  ...inputStyle,
  ...(missingProjection && quoteError ? requiredInputStyle : {}),
}}
              />

            </label>
{/* Tile system + colour */}
            <label>Tile system
              <select
                value={tileSystem}
                onChange={(e) => {setTileSystem(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={inputStyle}
              >
                <option value="britmet">Britmet</option>
                <option value="liteslate">LiteSlate</option>
              </select>
            </label>

            <label>Tile colour
              <select
                value={tileColor}
                onChange={(e) => {setTileColor(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={inputStyle}
              >
                {(tileSystem === "liteslate" ? liteslateColours : britmetColours).map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </label>
            {/* Fascia/Soffit colour (cosmetic) */}
            <label>Fascia / Soffit colour
              <select
                value={plasticsColor}
                onChange={(e) => {setPlasticsColor(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={inputStyle}
              >
                <option value="White">White</option>
                <option value="Rosewood">Rosewood</option>
                <option value="Black">Black</option>
                <option value="Anthracite">Anthracite</option>
                <option value="Light Oak">Light Oak</option>
                <option value="Cream">Cream</option>
              </select>
              {plasticsColor === "Cream" && (
                <div style={{ color: "#b45309", fontSize: 12, marginTop: 4 }}>
                  Cream: Priced on request
                </div>
              )}
            </label>
            <label>Soffit to Front (mm)
  <input
    type="number"
    value={eavesOverhangMM}
onChange={(e) => {
  const v = e.target.value;

  // Allow empty input
  if (v === "") {
    setEavesOverhang("");
    return;
  }

  const numVal = Number(v);
  if (!Number.isNaN(numVal)) {
    setEavesOverhang(numVal);
    persist({ soffit_mm: numVal });
  }
}}
    style={inputStyle}
  />
</label>
{/* Gutter style + colour */}
            <label>Gutter profile
              <select
                value={gutterProfile}
                onChange={(e) => {setGutterProfile(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={inputStyle}
              >
                <option value="square">Square</option>
                <option value="round">Round</option>
                <option value="ogee">Ogee</option>
              </select>
            </label>

            <label>Gutter colour
              <select
                value={gutterColor}
                onChange={(e) => {setGutterColor(e.target.value);
  persist({ projectionMM: e.target.value });
}}
                style={inputStyle}
              >
                <option value="black">Black</option>
                <option value="white">White</option>
                <option value="anthracite">Anthracite</option>
                <option value="brown">Brown</option>
              </select>
            </label>
 
            <label>Pitch (degrees)
              <input
                type="number"
                step="0.1"
                value={pitchDeg}
                disabled={maximumHeightIsActive}
onChange={(e) => {
  const v = e.target.value;

  if (v === "") {
    setPitch("");
    return;
  }

  const numVal = Number(v);
  if (!Number.isNaN(numVal)) {
    setPitch(numVal);
    persist({ pitch: numVal });
  }
}}
                style={{
  ...inputStyle,
  background: maximumHeightIsActive
    ? "#f3f4f6"
    : "#fff",
}}
              />
              {Number(pitchDeg) < minTilePitchDeg && (
  <div
    style={{
      color: "#b45309",
      fontSize: 12,
      marginTop: 4,
    }}
  >
    Recommended minimum for{" "}
    {tileSystem === "liteslate"
      ? "LiteSlate"
      : "Britmet"}{" "}
    is {minTilePitchDeg}°. Please confirm suitability
    if you go lower.
  </div>
)}
            </label>
            {roofStyle !== "hippedLeanTo" && (
  <label>
    Maximum finished height (mm)

    <input
      type="number"
      min="0"
      step="1"
      value={maximumFinishedHeightMM}
      placeholder="Optional"
      onChange={(e) => {
        const value = e.target.value;

        setMaximumFinishedHeightMM(value);

        persist({
          maximumFinishedHeightMM:
            value === ""
              ? null
              : Number(value),
        });
      }}
      style={inputStyle}
    />

    {maximumHeightIsActive &&
      !maximumHeightIsImpossible && (
        <div
          style={{
            color: "#047857",
            fontSize: 12,
            marginTop: 4,
          }}
        >
          Pitch calculated from height restriction:{" "}
          {Number(pitchDeg).toFixed(1)}°
        </div>
      )}

    {maximumHeightIsImpossible && (
      <div
        style={{
          color: "#b91c1c",
          fontSize: 12,
          marginTop: 4,
        }}
      >
        This height is below the minimum physical roof
        build-up.
      </div>
    )}
  </label>
)}

{roofStyle !== "hippedLeanTo" && (
  <div
    style={{
      display: "grid",
      gap: 10,
      gridColumn: "1 / -1",
      gridTemplateColumns:
        isMobile ? "1fr" : "1fr 1fr",
    }}
  >
    {/* LEFT SIDE */}
    <div
      style={{
        border: "1px solid #d1d5db",
        borderRadius: 8,
        padding: 10,
      }}
    >
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={leftWall}
          onChange={(e) => {
            const v = e.target.checked;

            setLeftWall(v);

            persist({
              left_wall_present: v,
              left_exposed: !v,
            });
          }}
        />

        Left side wall present
      </label>

      {!leftWall && (
        <label
          style={{
            display: "block",
            marginTop: 8,
          }}
        >
          Left support depth (mm)

          <input
            type="number"
            value={leftSupportDepthMM}
            onChange={(e) => {
              const v = e.target.value;

              if (v === "") {
                setLeftSupportDepthMM("");
                return;
              }

              const n = Number(v);

              if (!Number.isNaN(n)) {
                setLeftSupportDepthMM(n);

                persist({
                  leftSupportDepthMM: n,
                });
              }
            }}
            style={inputStyle}
          />
        </label>
      )}
    </div>

    {/* RIGHT SIDE */}
    <div
      style={{
        border: "1px solid #d1d5db",
        borderRadius: 8,
        padding: 10,
      }}
    >
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={rightWall}
          onChange={(e) => {
            const v = e.target.checked;

            setRightWall(v);

            persist({
              right_wall_present: v,
              right_exposed: !v,
            });
          }}
        />

        Right side wall present
      </label>

      {!rightWall && (
        <label
          style={{
            display: "block",
            marginTop: 8,
          }}
        >
          Right support depth (mm)

          <input
            type="number"
            value={rightSupportDepthMM}
            onChange={(e) => {
              const v = e.target.value;

              if (v === "") {
                setRightSupportDepthMM("");
                return;
              }

              const n = Number(v);

              if (!Number.isNaN(n)) {
                setRightSupportDepthMM(n);

                persist({
                  rightSupportDepthMM: n,
                });
              }
            }}
            style={inputStyle}
          />
        </label>
      )}
    </div>
  </div>
)}
{roofStyle === "hippedLeanTo" && (
  <div style={{ gridColumn: "1 / -1" }}>
    <HippedLeanToOptions
    leftHip={leftHip}
    setLeftHip={setLeftHip}
    rightHip={rightHip}
    setRightHip={setRightHip}
    leftHipWidthMM={leftHipWidthMM}
    setLeftHipWidthMM={setLeftHipWidthMM}
    rightHipWidthMM={rightHipWidthMM}
    setRightHipWidthMM={setRightHipWidthMM}
    requestedLeftSidePitchDeg={
  requestedLeftSidePitchDeg
}
setRequestedLeftSidePitchDeg={
  setRequestedLeftSidePitchDeg
}

requestedRightSidePitchDeg={
  requestedRightSidePitchDeg
}
setRequestedRightSidePitchDeg={
  setRequestedRightSidePitchDeg
}
    setLeftHipWidthManual={setLeftHipWidthManual}
    setRightHipWidthManual={setRightHipWidthManual}
    leftWall={leftWall}
    setLeftWall={setLeftWall}
    rightWall={rightWall}
    setRightWall={setRightWall}
    tileSystem={tileSystem}
    minTilePitchDeg={minTilePitchDeg}
    leftSidePitchDeg={leftSidePitchDeg}
    rightSidePitchDeg={rightSidePitchDeg}
    leftHipPitchTooLow={leftHipPitchTooLow}
    rightHipPitchTooLow={rightHipPitchTooLow}
    persist={persist}
      />
  </div>
)}
            

            {(roofStyle !== "hippedLeanTo" || (!leftHip && !leftWall)) && (
  <label>Left Overhang? (mm)
    <input
      type="number"
      placeholder="e.g. 150"
      value={leftOverhangMM}
      onChange={(e) => {
        const v = e.target.value;
        setLeftOverhang(v);
        persist({ left_overhang_mm: Number(v || 0) });
      }}
      style={inputStyle}
    />
  </label>
)}

            {(roofStyle !== "hippedLeanTo" || (!rightHip && !rightWall)) && (
  <label>Right Overhang? (mm)
    <input
      type="number"
      placeholder="e.g. 150"
      value={rightOverhangMM}
      onChange={(e) => {
        const v = e.target.value;
        setRightOverhang(v);
        persist({ right_overhang_mm: Number(v || 0) });
      }}
      style={inputStyle}
    />
  </label>
)}

      <label> Delivery postcode {isAdmin ? "(optional)" : ""}
  <input
    type="text"
    value={deliveryPostcode}
    style={missingPostcode && quoteError ? requiredInputStyle : undefined}
    onChange={(e) => {
  const v = e.target.value.toUpperCase();

  setDeliveryPostcode(v);

  persist({
    deliveryPostcode: v,
  });
}}
    onBlur={lookupDeliveryDistance}
onKeyDown={(e) => {
  if (e.key === "Enter") {
    lookupDeliveryDistance();
  }
}}
    style={inputStyle}
  />
  {deliveryLoading && (
    <div style={{ color: "#6b7280", fontSize: 12, marginTop: 4 }}>
      Checking delivery distance...
    </div>
  )}
  
  {deliveryError && (
    <div style={{ color: "#b91c1c", fontSize: 12, marginTop: 4 }}>
      {deliveryError}
    </div>
  )}
</label>
{/* Save with reference */}
            <label>
  Customer Reference
  <input
    type="text"
    value={quoteRef}
    onChange={(e) => {
  const v = e.target.value;
  setQuoteRef(v);
  persist({ quoteRef: v });
}}
    placeholder="e.g. SMITH"
    style={{
      ...inputStyle,
      minWidth: 160,
    }}
  />
</label>
    {/* TEMP HIDDEN – Gutter outlet not needed for now */}
{false && (
         <label>Gutter outlet position
  <select
    value={gutterOutlet}
    onChange={(e) => {
      const v = e.target.value;
      setGutterOutlet(v);
      persist({ gutter_outlet: v });
    }}
    style={inputStyle}
  >
                <option value="left">Left</option>
                <option value="right">Right</option>
                <option value="center">Center</option>
                <option value="both">Both ends</option>
                <option value="none">None</option>
              </select>
            </label>
)}
          </div>
          
{isAdmin && (
  <div style={{ marginTop: 12 }}>
    <label>
      Customer
      <select
        value={selectedCustomerId}
        onChange={(e) => {
  const id = e.target.value;
  setSelectedCustomerId(id);

  const selected = customers.find((c) => c.id === id);

  persist({
    selectedCustomerId: id,
    customerName: id === "retail" ? "Retail" : selected?.name || "",
    discountPct: id === "retail" ? 0 : Number(selected?.discountPct || 0),
  });
}}
        style={{ marginLeft: 10, padding: 6 }}
      >
        <option value="retail">Retail (No Discount)</option>

        {customers.map((c) => (
          <option key={c.id} value={c.id}>
            {c.name} ({Number(c.discountPct || 0)}%)
          </option>
        ))}
      </select>
    </label>
  </div>
)}
          <div
  style={{
    marginTop: 14,
    display: "grid",
    gridTemplateColumns: isMobile ? "1fr" : "repeat(3, 1fr)",
    gap: 10,
  }}
>
            <button
              onClick={onGetQuote}
              style={{ ...primaryBtn, width: "100%" }}
              title={
  !Number(widthMM) || !Number(projMM)
    ? "Enter width & projection first"
    : !hasDeliveryPostcode
    ? "Enter delivery postcode first"
    : "Generate price & plan"
}
        
        >
              Quote
            </button>
            {quoteError && (
            <div style={{ color: "#b91c1c", fontSize: 13, marginTop: 6 }}>
    {quoteError}
  </div>
)}

            

            <button
              onClick={saveQuote}
              style={{ ...primaryBtn, width: "100%", background: "#10b981", borderColor: "#10b981" }}
              disabled={!canQuote || (!isAdmin && !quoteRef.trim())}
title={
  !canQuote
    ? "Enter the required roof details first"
    : !isAdmin && !quoteRef.trim()
    ? "Please enter a customer reference"
    : "Save this quotation"
}
            >
              Save Quote
            </button>

            <button
              onClick={resetAll}
              style={{ ...primaryBtn, width: "100%", background: "#64748b", borderColor: "#64748b" }}
              title="Clear all fields and current stored quote"
            >
              Reset
            </button>
          </div>
        </div>

        {/* Results */}
        {showQuote && (
          <div id="quote-result" style={{ marginTop: 16, display: "grid", gap: 14 }}>
            {/* Plan preview */}
            <div style={card}>
              <h2 style={h2}>Plan preview</h2>
              <div style={{ border: "1px solid #e5e7eb", borderRadius: 8, padding: 12 }}>
                {roofStyle === "hippedLeanTo" ? (
  <PlanDiagramHippedLeanTo
  isAdmin={isAdmin}
  iw={num(widthMM)}
  ip={num(projMM)}

  leftHipWidth={
  hippedGeom?.leftPitchDerivedHipWidthMM ??
  num(leftHipWidthMM, 1000)
}

rightHipWidth={
  hippedGeom?.rightPitchDerivedHipWidthMM ??
  num(rightHipWidthMM, 1000)
}

frontRafterLayout={
  hippedGeom?.frontRafterLayoutV2
}

  hippedSides={activeHippedSides}
  pitchDeg={num(pitchDeg, 15)}

  leftSidePitchDeg={hippedGeom?.leftSidePitchDeg}
  rightSidePitchDeg={hippedGeom?.rightSidePitchDeg}
  soffitDepthMM={num(eavesOverhangMM)}
  rafterSpacing={num(m.rafter_spacing_mm ?? 665)}
  firstCentre={num(m.rafter_first_center_mm ?? 690)}
  tileSystem={tileSystem}

  externalWidthMM={hippedGeom?.externalWidthMM}
  externalProjectionMM={hippedGeom?.externalProjectionMM}

  leftExternalAllowanceMM={hippedGeom?.leftExternalAllowanceMM}
  rightExternalAllowanceMM={hippedGeom?.rightExternalAllowanceMM}

  leftSideRingBeamLayout={hippedGeom?.leftSideRingBeamLayout}
  rightSideRingBeamLayout={hippedGeom?.rightSideRingBeamLayout}

  leftBoundaryType={hippedGeom?.leftBoundaryType}
  rightBoundaryType={hippedGeom?.rightBoundaryType}

  leftWall={leftWall}
  rightWall={rightWall}
/>
) : (
  <PlanDiagramLeanTo
  iw={num(widthMM)}
  ip={num(projMM)}

  sft={num(m.side_frame_thickness_mm ?? 70)}

  leftSupportDepthMM={
    num(leftSupportDepthMM, 70)
  }

  rightSupportDepthMM={
    num(rightSupportDepthMM, 70)
  }

  lip={num(m.fascia_lip_mm ?? 25)}
    soffit={num(eavesOverhangMM)}
    frameOn={num(m.frame_on_mm ?? 70)}
    leftOH={num(leftOverhangMM, 0)}
    rightOH={num(rightOverhangMM, 0)}
    leftWall={leftWall}
    rightWall={rightWall}
    rafterSpacing={num(m.rafter_spacing_mm ?? 665)}
    firstCentre={num(m.rafter_first_center_mm ?? 690)}
    pitchDeg={num(pitchDeg, 15)}
    outlet={gutterOutlet}
    gutterColor={gutterColor}
    
  />
)}
              </div>

              <div style={{ marginTop: 10, color: "#444", display: "grid", gap: 4 }}>
                <div>
                  <b>Internal width</b>: {round(widthMM)} mm · <b>External width</b>: {round(displayExtWidthMM)} mm
                </div>
                <div>
                  <b>Internal projection</b>: {round(projMM)} mm · <b>External projection</b>: {round(displayExtProjectionMM)} mm
                </div>
                <div>
  <b>External Finished Height</b>: {round(externalFinishedHeightMM)} mm
</div>
<p>
  Rise:{" "}
  {Math.round(
    roofStyle === "hippedLeanTo"
      ? hippedGeom?.riseMM ?? 0
      : riseMM
  )}{" "}
  mm
</p>
<div>
  <b>Front Pitch</b>: {Number(pitchDeg || 0).toFixed(1)}°
</div>
{roofStyle === "hippedLeanTo" && hippedGeom && (
  <div
    style={{
      marginTop: 16,
      padding: 12,
      border: "2px solid #f59e0b",
      borderRadius: 8,
      background: "#fffbeb",
      fontSize: 13,
      lineHeight: 1.6,
    }}
    
  >
    <h3>
  HIP GEOMETRY / MANUFACTURE DEBUG
</h3>

<div>
  <b>Left Hip Width:</b>{" "}
  {Math.round(hippedGeom.leftHipWidthMM ?? 0)} mm
</div>

<div>
  <b>Pitch-Derived Left HP:</b>{" "}
  {Number(
    hippedGeom.leftPitchDerivedHipWidthMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Pitch-Derived Right HP:</b>{" "}
  {Number(
    hippedGeom.rightPitchDerivedHipWidthMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Input Projection:</b>{" "}
  {Math.round(hippedGeom.projectionMM ?? 0)} mm
</div>

<div>
  <b>Effective Pitch Run:</b>{" "}
  {Math.round(hippedGeom.effectivePitchRunMM ?? 0)} mm
</div>

<div>
  <b>Design Rise:</b>{" "}
  {Math.round(
    hippedGeom.designRiseMM ?? 0
  )} mm
</div>

<div>
  <b>Front-Rafter Face Rise:</b>{" "}
  {Math.round(
    hippedGeom.frontRafterFaceRiseMM ?? 0
  )} mm
</div>

<div>
  <b>Required Internal Wallplate Height:</b>{" "}
  {Math.round(
    hippedGeom.designInternalWallplateHeightMM ?? 0
  )} mm
</div>

<div>
  <b>Required External Wallplate Height:</b>{" "}
  {Math.round(
    hippedGeom.designExternalWallplateHeightMM ?? 0
  )} mm
</div>

<hr style={{ margin: "10px 0" }} />

<div style={{ marginTop: 6 }}>
  <b>FACET GEOMETRY:</b>
</div>

<div>
  Intersection offset:{" "}
  {Number(
    hippedGeom
      ?.rightFacetGeometry
      ?.intersectionOffsetMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>

<div>
  Resolved HP:{" "}
  {Number(
    hippedGeom?.leftPitchDerivedHipWidthMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>


<div>
  EWBS:{" "}
  {Number(
    hippedGeom
      ?.rightFacetGeometry
      ?.externalWallBarSlopeMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>

<div>
  IWBS:{" "}
  {Number(
    hippedGeom
      ?.rightFacetGeometry
      ?.internalWallBarSlopeMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>

<div>
  <b>EWPL:</b>{" "}
  {Number(
    hippedGeom?.horizontalWallplateExternalLengthMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>

<div>
  <b>IWPL:</b>{" "}
  {Number(
    hippedGeom?.horizontalWallplateInternalLengthMM ?? 0
  ).toFixed(1)}{" "}
  mm
</div>

<div>
  <b>Hip Plan Length:</b>{" "}
  {Math.round(hippedGeom.leftHipPlanLengthMM ?? 0)} mm
</div>

<div>
  <b>Hip Pitch:</b>{" "}
  {Number(
    hippedGeom.leftHipPitchDeg ?? 0
  ).toFixed(2)}°
</div>

<div>
  <b>Structural Hip Length:</b>{" "}
  {Math.round(
    hippedGeom.leftHipStructuralLengthMM ?? 0
  )} mm
</div>

<div>
  <b>Spar-Hook Extension:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufacture
      ?.sparHookAllowanceMM ?? 0
  )} mm
</div>

<div>
  <b>Finished Workshop Cut:</b>{" "}
  {Math.round(
    hippedGeom.leftHipFinishedCutLengthMM ?? 0
  )} mm
</div>
<hr style={{ margin: "10px 0" }} />

<div style={{ fontWeight: 800 }}>
  V2 GEOMETRY
</div>

<div>
  <b>V2 Internal Edge B–C:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufactureV2
      ?.internalSlopeLengthMM ?? 0
  )} mm
</div>

<div>
  <b>V2 External Edge A–D:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufactureV2
      ?.externalSlopeLengthMM ?? 0
  )} mm
</div>

<div>
  <b>V2 Horizontal Foot C–E:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufactureV2
      ?.horizontalFootCutMM ?? 0
  )} mm
</div>

<div>
  <b>V2 Vertical Foot D–E:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufactureV2
      ?.verticalFootCutMM ?? 0
  )} mm
</div>

<div>
  <b>V2 Top Vertical Cut A–B:</b>{" "}
  {Math.round(
    hippedGeom.leftHipManufactureV2
      ?.topVerticalCutMM ?? 0
  )} mm
</div>

<div style={{ marginTop: 8 }}>
  <b>Front Horizontal Allowance:</b>{" "}
  {Math.round(
    hippedGeom.frontHipHorizontalAllowanceMM ?? 0
  )} mm
</div>

<div>
  <b>Left Horizontal Allowance:</b>{" "}
  {Math.round(
    hippedGeom.leftHipHorizontalAllowanceMM ?? 0
  )} mm
</div>

<hr style={{ margin: "10px 0" }} />

<div style={{ fontWeight: 800 }}>
  FACET EAVES / SIDE SOFFIT DEBUG
</div>

<hr style={{ margin: "10px 0" }} />

<div style={{ fontWeight: 800 }}>
  FRONT RAFTER TEMPLATE
</div>

<div>
  <b>Pitch:</b>{" "}
  {Number(
    hippedGeom.frontTemplateDebug?.pitchDeg ?? 0
  ).toFixed(2)}°
</div>

<div>
  <b>Entered Soffit:</b>{" "}
  {Number(
    hippedGeom.frontTemplateDebug?.soffitDepthMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Frame + Soffit Foot Run:</b>{" "}
  {Number(
    hippedGeom.frontTemplateDebug
      ?.horizontalFootRunMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Fall Across Foot:</b>{" "}
  {Number(
    hippedGeom.frontTemplateDebug
      ?.verticalFallAcrossFootMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Vertical Plumb Cut:</b>{" "}
  {Number(
    hippedGeom.frontTemplateDebug
      ?.plumbCutHeightMM ?? 0
  ).toFixed(1)} mm
</div>

<hr style={{ margin: "10px 0" }} />

<div style={{ fontWeight: 800 }}>
  LEFT SIDE RAFTER TEMPLATE
</div>

<div>
  <b>Pitch:</b>{" "}
  {Number(
    hippedGeom.leftTemplateDebug?.pitchDeg ?? 0
  ).toFixed(2)}°
</div>

<div>
  <b>Matched Soffit:</b>{" "}
  {Number(
    hippedGeom.leftTemplateDebug?.soffitDepthMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Frame + Soffit Foot Run:</b>{" "}
  {Number(
    hippedGeom.leftTemplateDebug
      ?.horizontalFootRunMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Fall Across Foot:</b>{" "}
  {Number(
    hippedGeom.leftTemplateDebug
      ?.verticalFallAcrossFootMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Vertical Plumb Cut:</b>{" "}
  {Number(
    hippedGeom.leftTemplateDebug
      ?.plumbCutHeightMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Side Soffit — Plumb-Cut Match:</b>{" "}
  {Number(
    hippedGeom.leftPlumbCutMatchedSoffitMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Side Mitre Trim:</b>{" "}
  {Number(
    hippedGeom.leftMitreTrimAllowanceMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Side Soffit — Raw Manufactured:</b>{" "}
  {Number(
    hippedGeom.leftRawManufacturedSoffitMM ?? 0
  ).toFixed(1)} mm
</div>

<div>
  <b>Side Soffit — Rounded Manufactured:</b>{" "}
  {Number(
    hippedGeom.leftRoundedManufacturedSoffitMM ?? 0
  ).toFixed(1)} mm
</div>

<div
  style={{
    marginTop: 10,
    paddingTop: 8,
    borderTop: "2px solid #f59e0b",
    fontWeight: 800,
  }}
>
  Physical finished hip cut target: 4125 mm
</div>
  </div>
)}
{roofStyle === "hippedLeanTo" && hippedGeom && (
  <div>
    {hippedGeom.leftSideRingBeam?.exists && (
      <>
        <b>Left Side Pitch</b>:{" "}
        {Number(leftSidePitchDeg || 0).toFixed(1)}°
      </>
    )}

    {hippedGeom.leftSideRingBeam?.exists &&
      hippedGeom.rightSideRingBeam?.exists && (
        <> · </>
      )}

    {hippedGeom.rightSideRingBeam?.exists && (
      <>
        <b>Right Side Pitch</b>:{" "}
        {Number(rightSidePitchDeg || 0).toFixed(1)}°
      </>
    )}
  </div>
)}
   {roofStyle === "hippedLeanTo" &&
  hippedGeom &&
  hippedGeom.frontTemplateDebug &&
  hippedGeom.leftTemplateDebug && (
    <TemplateGeometryVisualizer
      frontTemplate={
        hippedGeom.frontTemplateDebug
      }
      sideTemplate={
        hippedGeom.leftTemplateDebug
      }
      matchedSideSoffitMM={
        hippedGeom.leftPlumbCutMatchedSoffitMM
      }
      mitreTrimAllowanceMM={
        hippedGeom.leftMitreTrimAllowanceMM
      }
      manufacturedSideSoffitMM={
        hippedGeom.leftRoundedManufacturedSoffitMM
      }
    />
  )}             
{roofStyle === "hippedLeanTo" && hippedGeom && (
  <WallplateGeometryVisualizer
    projectionMM={hippedGeom.projectionMM}
    frontPitchDeg={hippedGeom.frontPitchDeg}

    designRiseMM={hippedGeom.designRiseMM}
    frontRafterFaceRiseMM={
      hippedGeom.frontRafterFaceRiseMM
    }

    effectivePitchRunMM={
      hippedGeom.effectivePitchRunMM
    }

    internalWallplateHeightMM={
      hippedGeom.designInternalWallplateHeightMM
    }

    externalWallplateHeightMM={
      hippedGeom.designExternalWallplateHeightMM
    }

    wallplateThicknessMM={
      hippedGeom.raw?.wallplateThicknessMM ?? 63
    }

    wallplateHeightMM={
      hippedGeom.wallplateHeightMM ?? 220
    }

    ringBeamHeightMM={
      hippedGeom.ringBeamHeightMM ?? 40
    }
  />
)}
{roofStyle === "hippedLeanTo" && hippedGeom && (
  <HippedWallplateFrontVisualizer
    internalWidthMM={hippedGeom.widthMM}

    leftHipPositionMM={
      hippedGeom.leftHipWidthMM
    }

    rightHipPositionMM={
      hippedGeom.rightHipWidthMM
    }

    leftSidePitchDeg={
      hippedGeom.leftSidePitchDeg
    }

    rightSidePitchDeg={
      hippedGeom.rightSidePitchDeg
    }

    internalWallplateHeightMM={
      hippedGeom.designInternalWallplateHeightMM
    }

    externalWallplateHeightMM={
      hippedGeom.designExternalWallplateHeightMM
    }

    wallplateSectionHeightMM={
      hippedGeom.wallplateHeightMM ?? 220
    }
leftWallBarFootRunMM={
  hippedGeom.leftTemplateDebug?.horizontalFootRunMM ?? 0
}

rightWallBarFootRunMM={
  hippedGeom.rightTemplateDebug?.horizontalFootRunMM ??
  hippedGeom.leftTemplateDebug?.horizontalFootRunMM ??
  0
}
leftWallBarVerticalFootCutMM={
  hippedGeom.leftPlumbCutHeightMM
}

rightWallBarVerticalFootCutMM={
  hippedGeom.rightPlumbCutHeightMM
}
    externalWidthMM={
      hippedGeom.externalWidthMM
    }

    leftExternalAllowanceMM={
      hippedGeom.leftExternalAllowanceMM
    }

    rightExternalAllowanceMM={
      hippedGeom.rightExternalAllowanceMM
    }
  />
)}
                <div>
                  <b>Tile</b>: {tileSystem === "britmet" ? "Britmet" : "LiteSlate"} — <b>{tileColor}</b>
                </div>
                <div>
                  <b>Fascia/Soffit</b>: <b>{plasticsColor}</b> · <b>Gutter</b>: {gutterProfile} / {gutterColor}, outlet {gutterOutlet}
                </div>
              </div>
              
            </div>

            {/* Price summary */}
<div style={card}>
  <h2 style={h2}>Your price</h2>
  <div style={{ display: "grid", gap: 6, fontSize: 16 }}>
    <div>
      Materials subtotal (net): <b>£{(pricing.net ?? 0).toFixed(2)}</b>
    </div>
    <div style={{ color: "#b45309", fontSize: 13 }}>
  Adjustment delta: £{adjustmentDelta.toFixed(2)}
</div>
<div style={{ color: "#6b7280", fontSize: 12 }}>
  Adjustment keys: {Object.keys(summaryAdjustments).join(", ")}
</div>
<div style={{ color: "#6b7280", fontSize: 12 }}>
  Available keys:
  {(totals?.allLines || [])
    .map((r) => r.key)
    .join(", ")}
</div>
    <div>
      VAT ({((pricing.vatRate ?? 0) * 100).toFixed(0)}%): £{(pricing.vat ?? 0).toFixed(2)}
    </div>
    <div style={{ fontSize: 18 }}>
      Total (gross): <b>£{(pricing.gross ?? 0).toFixed(2)}</b>
    </div>
  </div>
  <div style={{ color: "#6b7280", fontSize: 12, marginTop: 8 }}>
    Includes tiles & ancillaries, fascia/soffit, gutters, tile starter, J-Section and membrane.
  </div>
</div>
          </div>
        )}
        <div
  style={{
    marginTop: 16,
    padding: 12,
    border: "1px solid #d1d5db",
    borderRadius: 8,
    background: "#f9fafb",
    fontSize: 13,
  }}
>
  {/*
<h3 style={{ margin: "0 0 8px", fontSize: 15 }}>
  Manufacturing geometry debug
</h3>

<p style={{ margin: "2px 0" }}>
  <b>User soffit:</b> {manufactureGeom.userSoffitMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Effective soffit:</b> {manufactureGeom.effectiveSoffitMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Internal rafter length:</b> {manufactureGeom.internalRafterLengthMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Horizontal extension:</b> {manufactureGeom.horizontalExtensionMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>External rafter extension:</b> {manufactureGeom.externalRafterExtensionMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Total rafter length:</b> {manufactureGeom.totalRafterLengthMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Vertical drop:</b> {manufactureGeom.verticalDropMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Plumb cut height:</b> {manufactureGeom.plumbCutHeightMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Finished fascia height:</b> {manufactureGeom.finishedFasciaHeightMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Fascia allowance:</b> {manufactureGeom.fasciaAllowanceMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Ordering fascia reference:</b> {manufactureGeom.fasciaOrderingReferenceMM} mm
</p>
<p style={{ margin: "2px 0" }}>
  <b>Order fascia size:</b> {manufactureGeom.fasciaOrderSizeMM} mm
</p>
*/}
</div>
      </div>
    </div>
  );
}
