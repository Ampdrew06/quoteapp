// src/components/PlanDiagramLeanToManufacture.jsx
import React, { useMemo } from "react";

const round = (v, dp = 0) => {
  const p = 10 ** dp;
  return Math.round((Number(v) || 0) * p) / p;
};

export default function PlanDiagramLeanToManufacture({
  iw, ip,
  sft, lip,
  leftSupportDepthMM,
  rightSupportDepthMM,
  soffit, frameOn,
  leftOH = 0, rightOH = 0,
  leftWall = false, rightWall = false,
  rafterSpacing = 665, firstCentre = 690,
  outlet = "left", gutterColor = "black",
  pitchDeg = 15,
}) {
  // --- compute per-side deltas (full rule set) ---
  const { extW, extP, leftDelta, rightDelta } = useMemo(() => {
  const FT = Number(sft) || 70;

const LEFT_FT =
  Number(leftSupportDepthMM) || FT;

const RIGHT_FT =
  Number(rightSupportDepthMM) || FT;

const LIP = Number(lip) || 25;
  const L_OH = Number(leftOH) || 0;
  const R_OH = Number(rightOH) || 0;

  const leftDelta = leftWall
  ? 0
  : (L_OH > 0
      ? LEFT_FT + L_OH
      : LEFT_FT + LIP);

const rightDelta = rightWall
  ? 0
  : (R_OH > 0
      ? RIGHT_FT + R_OH
      : RIGHT_FT + LIP);

  const extW = iw + leftDelta + rightDelta;
  const extP = ip + (Number(frameOn) || 70) + (Number(soffit) || 150);

  return { extW, extP, leftDelta, rightDelta };
}, [
  iw,
  ip,
  sft,
  lip,
  leftSupportDepthMM,
  rightSupportDepthMM,
  soffit,
  frameOn,
  leftOH,
  rightOH,
  leftWall,
  rightWall,
]);

  // --- drawing area setup ---
  const VB_W = 900, VB_H = 520;

// tighter drawing margins, but still enough room for labels
const M_TOP = 12;
const M_RIGHT = 20;
const M_BOTTOM = 54;
const M_LEFT = 10;

const innerW = VB_W - M_LEFT - M_RIGHT;
const innerH = VB_H - M_TOP - M_BOTTOM;
const scale = Math.min(
  innerW / Math.max(1, extW),
  innerH / Math.max(1, extP)
);

const ow = extW * scale;
const oh = extP * scale;

// centre the whole drawing block within the available area
const ox = M_LEFT + (innerW - ow) / 2;
const oy = M_TOP + (innerH - oh) / 2 + 14;

  // --- internal rect (wall top → eaves bottom) ---
  const ix = ox + leftDelta * scale;
  const iy = oy + (frameOn * scale); // wall is top; frameOn offsets downward
  const iw_px = iw * scale;
  const ip_px = ip * scale;

  // --- rafters ---
  const centres = [];
  for (let c = firstCentre; c <= iw; c += rafterSpacing) centres.push(c);

  // Include the two edge rafters so we can display each
// individual centre-to-centre bay rather than cumulative positions.
const rafterPositionsMM = [
  0,
  ...centres.filter((c) => c > 0 && c < iw),
  iw,
];

const rafterBays = rafterPositionsMM
  .slice(0, -1)
  .map((startMM, index) => ({
    startMM,
    endMM: rafterPositionsMM[index + 1],
    spacingMM: rafterPositionsMM[index + 1] - startMM,
  }));

  const rafterStroke = Math.max(2, Math.min(6, 0.005 * iw_px + 2));
  const labelFont = "14px Inter, system-ui, Arial";
  const faint = "#6b7280";

  const uid = "pdlt";
  const arrId = `arr-${uid}`;
  const arrYId = `arrY-${uid}`;

  const DimX = ({ x1, x2, y, text }) => {
    const mid = (x1 + x2) / 2;
    return (
      <g>
        <line
          x1={x1} y1={y} x2={x2} y2={y}
          stroke="#374151" strokeWidth="1.5"
          markerStart={`url(#${arrId})`} markerEnd={`url(#${arrId})`}
        />
        <text x={mid} y={y - 6} textAnchor="middle"
          style={{ font: labelFont }} fill="#111827">{text}</text>
      </g>
    );
  };

  const DimY = ({ x, y1, y2, text }) => {
    const mid = (y1 + y2) / 2;
    return (
      <g>
        <line
          x1={x} y1={y1} x2={x} y2={y2}
          stroke="#374151" strokeWidth="1.5"
          markerStart={`url(#${arrYId})`} markerEnd={`url(#${arrYId})`}
        />
        <text
          x={x - 6} y={mid} textAnchor="end"
          style={{ font: labelFont }} fill="#111827"
          transform={`rotate(-90 ${x - 6} ${mid})`}
        >
          {text}
        </text>
      </g>
    );
  };

  const dim = (n) => `${round(n, 0)}`;

  // --- render ---
  return (
    <svg
  width="100%"
  height="560"
  viewBox={`0 0 ${VB_W} ${VB_H}`}
  preserveAspectRatio="xMidYMid meet"
>
      <defs>
        <marker id={arrId} markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto-start-reverse">
          <path d="M0,0 L6,3 L0,6" fill="none" stroke="#374151" strokeWidth="1.5" />
        </marker>
        <marker id={arrYId} markerWidth="10" markerHeight="10" refX="5" refY="3" orient="auto-start-reverse">
          <path d="M0,0 L6,3 L0,6" fill="none" stroke="#374151" strokeWidth="1.5" />
        </marker>
      </defs>

      {/* --- external rectangle (wall = top, eaves = bottom) --- */}
      <rect x={ox} y={oy} width={ow} height={oh} fill="#f8fafc" stroke="#111827" strokeWidth="2" />

      {/* --- internal rectangle --- */}
      <rect
        x={ix}
        y={oy + oh - ip_px - (soffit * scale)}   // push down so eaves at bottom
        width={iw_px}
        height={ip_px}
        fill="#ffffff"
        stroke="#1f2937"
        strokeWidth="1.5"
      />

      {/* --- rafters --- */}
      {centres.map((mm, i) => {
  const x = ix + mm * scale;

  return (
    <g key={i}>
      <line
        x1={x}
        y1={oy}
        x2={x}
        y2={oy + oh}
        stroke="#2563eb"
        strokeWidth={rafterStroke}
      />

      {/* Cumulative rafter position */}
      <text
        x={x}
        y={oy + oh + 16}
        textAnchor="middle"
        style={{
          font: labelFont,
          fontWeight: 700,
        }}
        fill="#111827"
      >
        {dim(mm)}
      </text>
    </g>
  );
})}

{/* Individual rafter bay spacings */}
{rafterBays.map((bay, i) => {
  const x1 = ix + bay.startMM * scale;
  const x2 = ix + bay.endMM * scale;
  const midX = (x1 + x2) / 2;

  return (
    <text
      key={`bay-${i}`}
      x={midX}
      y={oy + oh - 10}
      textAnchor="middle"
      style={{ font: "11px Inter, system-ui, Arial" }}
fill="#6b7280"
    >
      {dim(bay.spacingMM)}
    </text>
  );
})}

      const M_TOP = 30, M_RIGHT = 35, M_BOTTOM = 55, M_LEFT = 35;

      {/* --- dimensions --- */}
      <DimX x1={ix} x2={ix + iw_px} y={oy - 8} text={`${dim(iw)} int`} />
      <DimX x1={ox} x2={ox + ow} y={oy + oh + 36} text={`${dim(extW)} ext`} />
      <DimY x={ox - 28} y1={oy} y2={oy + oh} text={`${dim(extP)} ext`} />
<DimY x={ox + ow + 28} y1={oy + oh - ip_px - (soffit * scale)} y2={oy + oh - (soffit * scale)} text={`${dim(ip)} int`} />

{/* --- pitch at centre of drawing --- */}
<text
  x={ox + ow / 2}
  y={oy + oh / 2}
  textAnchor="middle"
  dominantBaseline="middle"
  style={{ font: "16px Inter, system-ui, Arial", fontWeight: 700 }}
  fill="#111827"
>
  {round(pitchDeg, 1)}°
</text>

{/* --- side labels on actual external edges, inside the roof outline --- */}
<g>
  <text
    x={ox + 14}
    y={oy + oh / 2}
    textAnchor="middle"
    dominantBaseline="middle"
    transform={`rotate(-90 ${ox + 14} ${oy + oh / 2})`}
    style={{ font: "12px Inter, system-ui, Arial", fontWeight: 700 }}
    fill="#111827"
  >
    {leftWall ? "WALL" : "END"}
  </text>

  <text
    x={ox + ow - 14}
    y={oy + oh / 2}
    textAnchor="middle"
    dominantBaseline="middle"
    transform={`rotate(90 ${ox + ow - 14} ${oy + oh / 2})`}
    style={{ font: "12px Inter, system-ui, Arial", fontWeight: 700 }}
    fill="#111827"
  >
    {rightWall ? "WALL" : "END"}
  </text>
</g>

      {/* --- gutter indicators (bottom edge) --- */}
      {(() => {
        const eavesY = oy + oh;
        const fill =
          gutterColor === "white" ? "#e5e7eb" :
          gutterColor === "anthracite" ? "#374151" :
          gutterColor === "brown" ? "#7c3e1d" : "#111827";

        const dot = (cx) => (
          <circle key={cx} cx={cx} cy={eavesY + 14} r={6} fill={fill} stroke="#111827" strokeWidth="1" />
        );

        const leftX = ox + 10;
        const rightX = ox + ow - 10;
        const centerX = ox + ow / 2;

        if (outlet === "none") return null;
        if (outlet === "left") return dot(leftX);
        if (outlet === "right") return dot(rightX);
        if (outlet === "center") return dot(centerX);
        if (outlet === "both") return <g>{[dot(leftX), dot(rightX)]}</g>;
        return null;
      })()}

      {/* --- faint baseline under bottom labels --- */}
      <polyline
        points={`${ox},${oy + oh} ${ox},${oy + oh + 8} ${ox + ow},${oy + oh + 8} ${ox + ow},${oy + oh}`}
        fill="none"
        stroke={faint}
        strokeWidth="1"
      />
    </svg>
  );
}
