// src/components/NavTabs.jsx
import React from "react";
import { NavLink } from "react-router-dom";
import { isAdminUser } from "../lib/userRole";

const publicTabsLeft = [
  { to: "/quote", label: "Home", exact: true },
  { to: "/quote/lean-to", label: "Design/Options", exact: true },
];

const adminTabsLeft = [
  ...publicTabsLeft,
  { to: "/quote/lean-to/plan-manufacture", label: "Manufacture Book" },
  // { to: "/quote/lean-to/tiles-laths", label: "Tiles & Laths" },
  { to: "/idiot-list", label: "Idiot List" },
  { to: "/summary", label: "Summary" },
  { to: "/quotes", label: "Quotes" },
  { to: "/jobs", label: "Jobs" },
  { to: "/customers", label: "Customers" },
];

export default function NavTabs() {
  const tabsLeft = isAdminUser() ? adminTabsLeft : publicTabsLeft;
  return (
    <div className="print:hidden nav-strip">
      <div className="nav-inner">
        {/* Left-side tabs */}
        <div className="nav-tabs-left">
          {tabsLeft.map((tab) => (
            <NavLink
              key={tab.to}
              to={tab.to}
              end={tab.exact}
              className={({ isActive }) =>
                "nav-tab" + (isActive ? " nav-tab-active" : "")
              }
            >
              {tab.label}
            </NavLink>
          ))}
        </div>

        {/* Right-side: Print + Materials (Admin only) */}
{isAdminUser() && (
  <div className="nav-tabs-right">
    <button
      type="button"
      onClick={() => window.print()}
      className="nav-tab nav-tab-ghost"
    >
      Print
    </button>

    <NavLink
      to="/materials"
      className={({ isActive }) =>
        "nav-tab" + (isActive ? " nav-tab-active" : "")
      }
    >
      Materials
    </NavLink>
  </div>
)}
      </div>
    </div>
  );
}
